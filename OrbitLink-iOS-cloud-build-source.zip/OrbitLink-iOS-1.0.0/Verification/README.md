# 本次检查范围

- source-check.json：工程/资源基础检查与 Swift 语法解析，具体数量见报告。没有执行 Swift 编译、类型检查、XCTest 或 Xcode。
- engine-config-check.json：官方 Windows sing-box v1.14.3 对七份代表配置执行离线 check，均返回 0。ConfigurationFixtures 是手写参考配置；并非运行 Swift Configuration.make 的输出，也不是已连接记录。
- control-api-check.json：对官方 Windows 核心启动临时、仅限本机的控制接口，没有 TUN 和代理入口；验证鉴权、选择切换、错误选择和流量字段，7 项通过。没有使用真实节点，也未改变系统代理或网络路由。
- provenance.json：版本、来源与报告哈希。Windows 检查用官方 ZIP SHA256 为 d8b86ef58936dba9230ec6a57ffa4243933f3c14ef4809828b6c553440ed1518，与发布页校验值一致；检查二进制未打入 iOS 源码包。

下一步必须在 Mac 上执行脚本、修复实际编译/链接问题，再用 iPhone 13 完成 ACCEPTANCE.md。当前不存在经验证的 iOS 框架、签名 IPA 或真机运行截图。
