import SwiftUI
import NetworkExtension

private let cyan = Color(red: 0.22, green: 0.89, blue: 1)
private let violet = Color(red: 0.65, green: 0.49, blue: 1)
private let panel = Color(red: 0.047, green: 0.08, blue: 0.145)

struct ContentView: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.scenePhase) private var scenePhase
    @State private var tab = 0
    @State private var importing = false
    @State private var region = "新加坡"
    @State private var search = ""
    @State private var manual: Node?
    @State private var clearConfirm = false
    var body: some View {
        ZStack {
            Color(red: 0.018, green: 0.031, blue: 0.067).ignoresSafeArea()
            VStack(spacing: 0) {
                HStack(spacing: 10) {
                    Image("OrbitMark").resizable().frame(width: 38, height: 38).cornerRadius(10)
                    VStack(alignment: .leading, spacing: 3) { Text("星枢").font(.title3.bold()); Text("ORBITLINK / MOBILE").font(.system(size: 9, weight: .medium, design: .monospaced)).tracking(2).foregroundStyle(cyan) }
                    Spacer()
                    Button { importing = true } label: { Image(systemName: "plus").font(.title3).padding(11).background(panel).clipShape(Circle()) }.accessibilityLabel("导入节点")
                }.padding(.horizontal, 20).padding(.vertical, 12)
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        if tab == 0 { dashboard }
                        else if tab == 1 { regions }
                        else { settings }
                    }.padding(20)
                }
                HStack {
                    nav("网络", icon: "waveform.path", index: 0)
                    nav("地区", icon: "globe.asia.australia", index: 1)
                    nav("设置", icon: "slider.horizontal.3", index: 2)
                }.padding(.top, 12).padding(.bottom, 8).background(panel.opacity(0.95))
            }
        }
        .tint(cyan)
        .onChange(of: model.intent.region) { value in if let value { region = value } }
        .sheet(isPresented: $importing) { ImportSheet() }
        .alert("星枢", isPresented: Binding(get: { model.banner != nil }, set: { if !$0 { model.banner = nil } })) { Button("知道了") { model.banner = nil } } message: { Text(model.banner ?? "") }
        .confirmationDialog("手动选择会退出地区自动优选", isPresented: Binding(get: { manual != nil }, set: { if !$0 { manual = nil } }), titleVisibility: .visible) {
            if let node = manual { Button("连接 " + node.name) { model.connect(node: node); manual = nil } }
            Button("取消", role: .cancel) { manual = nil }
        }
        .confirmationDialog("清空全部节点？", isPresented: $clearConfirm, titleVisibility: .visible) { Button("清空节点", role: .destructive) { model.deleteNodes() } }
        .task(id: scenePhase) {
            guard scenePhase == .active else { return }
            await model.reload()
            while !Task.isCancelled {
                await model.poll()
                do { try await Task.sleep(nanoseconds: 2_000_000_000) } catch { return }
            }
        }
    }
    private func nav(_ title: String, icon: String, index: Int) -> some View {
        Button { tab = index } label: { VStack(spacing: 5) { Image(systemName: icon).font(.system(size: 20)); Text(title).font(.caption) }.frame(maxWidth: .infinity).foregroundStyle(tab == index ? cyan : Color.gray) }
    }
    private var statusColor: Color { model.verified ? Color.green : model.running ? Color.orange : cyan }
    private var dashboard: some View {
        Group {
            HStack { Text("网络指挥中心").font(.title2.bold()); Spacer(); Text("iPHONE").font(.system(size: 10, design: .monospaced)).foregroundStyle(.secondary) }
            VStack(spacing: 16) {
                HStack { Label(model.statusText, systemImage: model.verified ? "checkmark.shield.fill" : "shield.lefthalf.filled").font(.caption).foregroundStyle(statusColor); Spacer(); Text(model.intent.region ?? "手动线路").font(.caption).foregroundStyle(violet) }
                OrbitAnimation(color: statusColor, animate: model.intent.animations && scenePhase == .active).frame(height: 190)
                Text(model.active?.name ?? (model.nodes.isEmpty ? "导入节点，开启连接" : "选择地区，自动连接优选节点")).font(.headline).multilineTextAlignment(.center).lineLimit(2)
                Text(model.running ? model.snapshot.message : "全局代理 · 局域网直连").font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
                Button { if model.running { model.disconnect() } else { model.connect() } } label: {
                    HStack { Image(systemName: "power"); Text(model.running ? "断开连接" : "连接并启用") }.font(.headline).frame(maxWidth: .infinity).padding(16).background(statusColor.opacity(0.18)).overlay(RoundedRectangle(cornerRadius: 14).stroke(statusColor.opacity(0.7))).cornerRadius(14)
                }.foregroundStyle(statusColor).disabled(model.status == .disconnecting)
            }.card()
            HStack(spacing: 12) {
                metric("下载速度", icon: "arrow.down", value: AppModel.speed(model.running ? model.snapshot.download : 0), color: cyan)
                metric("上传速度", icon: "arrow.up", value: AppModel.speed(model.running ? model.snapshot.upload : 0), color: violet)
            }
            VStack(alignment: .leading, spacing: 14) {
                HStack { Text("链路遥测").font(.headline); Spacer(); Text(model.verified ? "\(model.snapshot.latency ?? 0) ms" : "待验证").font(.system(.caption, design: .monospaced)).foregroundStyle(statusColor) }
                TrafficChart(download: model.downloadHistory, upload: model.uploadHistory).frame(height: 90)
                Text("速度来自 VPN 核心；未连接时不显示模拟流量").font(.caption2).foregroundStyle(.secondary)
            }.card()
            HStack { Text("地区快速连接").font(.headline); Spacer(); Button("全部线路") { tab = 1 }.font(.caption) }
            regionChips
            if !model.snapshot.events.isEmpty {
                VStack(alignment: .leading, spacing: 12) {
                    Text("恢复记录").font(.headline)
                    ForEach(model.snapshot.events.prefix(4)) { event in HStack(alignment: .top) { Text(event.time, style: .time).font(.caption2.monospacedDigit()).foregroundStyle(.secondary); Text(event.text).font(.caption) } }
                }.card()
            }
        }
    }
    private func metric(_ title: String, icon: String, value: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 12) { Label(title, systemImage: icon).font(.caption).foregroundStyle(.secondary); Text(value).font(.system(size: 20, weight: .medium, design: .monospaced)).minimumScaleFactor(0.65).lineLimit(1).foregroundStyle(color) }.frame(maxWidth: .infinity, alignment: .leading).card()
    }
    private var regionChips: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
            ForEach(Regions.primary, id: \.self) { name in
                let count = model.nodes.filter { $0.region == name }.count
                Button { region = name; model.connect(region: name) } label: {
                    HStack { Text(name).font(.subheadline.bold()); Spacer(); Text("\(count)").font(.caption.monospacedDigit()) }.padding(15).background(model.intent.region == name ? cyan.opacity(0.14) : panel).overlay(RoundedRectangle(cornerRadius: 12).stroke(model.intent.region == name ? cyan.opacity(0.8) : Color.white.opacity(0.08))).cornerRadius(12)
                }.foregroundStyle(count == 0 ? Color.gray : cyan).disabled(count == 0)
            }
        }
    }
    private var regions: some View {
        Group {
            Text("地区线路").font(.title2.bold())
            Text("点击地区即可检测并连接优选线路；连续失败 3 次后自动尝试同地区备用节点。").font(.caption).foregroundStyle(.secondary)
            regionChips
            HStack { ForEach(["香港", "未识别"], id: \.self) { name in Button(name) { region = name }.font(.caption).padding(10).background(panel).cornerRadius(9) }; Spacer(); Text(region).font(.caption).foregroundStyle(violet) }
            TextField("搜索节点名称", text: $search).textFieldStyle(.roundedBorder)
            if visibleNodes.isEmpty { Text("这个地区暂无节点，请导入订阅。未识别节点可手动连接。").font(.subheadline).foregroundStyle(.secondary).padding(.vertical, 30) }
            ForEach(visibleNodes) { node in
                Button { manual = node } label: {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack { Text(node.name).font(.subheadline.bold()).lineLimit(2); Spacer(); if model.snapshot.activeID == node.id && model.running { Image(systemName: "checkmark.circle.fill").foregroundStyle(model.verified ? .green : .orange) } }
                        HStack {
                            Text(node.type).font(.system(size: 10, design: .monospaced)).foregroundStyle(violet)
                            Spacer()
                            if let q = model.snapshot.qualities[node.id], q.usable(now: ProcessInfo.processInfo.systemUptime) {
                                Text("\(q.median) ms · 成功 \(Int(q.success * 100))% · 波动 \(q.jitter)").font(.caption2).foregroundStyle(cyan)
                            } else { Text("等待检测").font(.caption2).foregroundStyle(.secondary) }
                        }
                        if (model.snapshot.blockedUntil[node.id] ?? 0) > ProcessInfo.processInfo.systemUptime { Label("故障隔离中，暂不自动选用", systemImage: "exclamationmark.triangle").font(.caption2).foregroundStyle(.orange) }
                        else if recommended?.id == node.id { Label("优先推荐", systemImage: "sparkles").font(.caption2).foregroundStyle(cyan) }
                    }.card()
                }.buttonStyle(.plain)
            }
        }
    }
    private var recommended: Node? { RoutePolicy.rank(model.nodes, region: region, quality: model.snapshot.qualities, blocked: model.snapshot.blockedUntil, now: ProcessInfo.processInfo.systemUptime).first }
    private var visibleNodes: [Node] {
        let values = model.nodes.filter { $0.region == region && (search.isEmpty || $0.name.localizedCaseInsensitiveContains(search)) }
        let ranked = RoutePolicy.rank(values, region: region, quality: model.snapshot.qualities, blocked: model.snapshot.blockedUntil, now: ProcessInfo.processInfo.systemUptime)
        let ids = Set(ranked.map(\.id)); return ranked + values.filter { !ids.contains($0.id) }
    }
    private var settings: some View {
        Group {
            Text("连接设置").font(.title2.bold())
            VStack(alignment: .leading, spacing: 18) {
                Toggle("断线自动恢复", isOn: $model.intent.automaticRecovery).disabled(model.running)
                Toggle("网络恢复时自动启动 VPN", isOn: $model.intent.onDemand).disabled(model.running)
                Toggle("动态轨道效果", isOn: $model.intent.animations).disabled(model.running)
                Text("地区模式限定同地区切换；手动选点退出地区优选。为避免循环切换，设置 90 秒冷却和每 10 分钟最多 3 次切换。").font(.caption).foregroundStyle(.secondary)
                Text("连接期间请先断开再修改设置。系统自动启动仅在你启用后生效；主动断开会关闭本次自动启动。").font(.caption2).foregroundStyle(.secondary)
            }.card().onChange(of: model.intent.automaticRecovery) { _ in model.saveSettings() }.onChange(of: model.intent.onDemand) { _ in model.saveSettings() }.onChange(of: model.intent.animations) { _ in model.saveSettings() }
            VStack(alignment: .leading, spacing: 16) {
                Button("导入订阅 / 分享链接") { importing = true }
                Button("清空所有节点", role: .destructive) { clearConfirm = true }.disabled(model.running)
                Text("节点仅保存在本机共享容器，启用系统文件保护并排除备份。不会自动读取剪贴板。").font(.caption2).foregroundStyle(.secondary)
            }.card()
            VStack(alignment: .leading, spacing: 10) {
                Text("星枢 · OrbitLink iOS 1.0 开发版").font(.subheadline.bold())
                Text("iPhone 13 · iOS 16 或更高\n原生 SwiftUI + sing-box / Libbox\nGPL-3.0-or-later").font(.caption).foregroundStyle(.secondary)
                Text("本工程尚待 Xcode 编译与 iPhone 真机验收。").font(.caption2).foregroundStyle(.orange)
                Link("开源核心与许可证", destination: URL(string: "https://github.com/SagerNet/sing-box/tree/v1.14.3")!).font(.caption)
            }.card()
        }
    }
}

private extension View {
    func card() -> some View { padding(18).background(panel).overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.075))).cornerRadius(18) }
}

private struct OrbitAnimation: View {
    let color: Color; let animate: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !animate || reduceMotion)) { timeline in
            let t = animate && !reduceMotion ? timeline.date.timeIntervalSinceReferenceDate : 0
            Canvas { context, size in
                let center = CGPoint(x: size.width / 2, y: size.height / 2)
                let r: CGFloat = 72
                for index in 0..<3 {
                    let radius = r + CGFloat(index) * 10
                    let rect = CGRect(x: center.x - radius, y: center.y - radius, width: radius * 2, height: radius * 2)
                    context.stroke(Path(ellipseIn: rect), with: .color(color.opacity(0.15)), lineWidth: 1)
                    var arc = Path(); arc.addArc(center: center, radius: radius, startAngle: .degrees(t * Double(18 + index * 7) + Double(index * 100)), endAngle: .degrees(t * Double(18 + index * 7) + Double(index * 100) + 125), clockwise: false)
                    context.stroke(arc, with: .color(index == 1 ? violet : color), style: StrokeStyle(lineWidth: 2.5, lineCap: .round))
                }
            }
            .overlay { VStack(spacing: 8) { Image(systemName: "network").font(.system(size: 38, weight: .light)); Text("ORBIT CORE").font(.system(size: 9, design: .monospaced)).tracking(2) }.foregroundStyle(color) }
            .accessibilityLabel("连接状态动态轨道")
        }
    }
}

private struct TrafficChart: View {
    let download: [Double]; let upload: [Double]
    var body: some View {
        Canvas { context, size in
            for row in 0...3 { let y = CGFloat(row) * size.height / 3; var path = Path(); path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y)); context.stroke(path, with: .color(.white.opacity(0.07)), lineWidth: 1) }
            let maximum = max(1024, (download + upload).max() ?? 0)
            for (values, color) in [(download, cyan), (upload, violet)] where values.count > 1 {
                var path = Path()
                for (i, value) in values.enumerated() { let point = CGPoint(x: CGFloat(i) / CGFloat(max(1, values.count - 1)) * size.width, y: size.height - CGFloat(value / maximum) * size.height * 0.9); if i == 0 { path.move(to: point) } else { path.addLine(to: point) } }
                context.stroke(path, with: .color(color), style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
            }
        }.accessibilityLabel("最近真实上传与下载速度曲线")
    }
}

private struct ImportSheet: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var text = ""
    @State private var scanning = false
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 16) {
                Text("输入 HTTPS 订阅地址，或粘贴 VLESS / VMess / Trojan / SS / HY2 分享链接及 sing-box JSON。").font(.subheadline).foregroundStyle(.secondary)
                TextEditor(text: $text).font(.system(.caption, design: .monospaced)).autocorrectionDisabled().textInputAutocapitalization(.never).frame(minHeight: 180).overlay(RoundedRectangle(cornerRadius: 10).stroke(.gray.opacity(0.3)))
                HStack { PasteButton(payloadType: String.self) { values in text = values.joined(separator: "\n") }; Spacer(); Button { scanning = true } label: { Label("扫码", systemImage: "qrcode.viewfinder") } }
                Button { Task { if await model.importText(text) { dismiss() } } } label: { HStack { if model.importing { ProgressView() }; Text(model.importing ? "正在导入" : "导入节点") }.frame(maxWidth: .infinity).padding() }.buttonStyle(.borderedProminent).disabled(model.importing || text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || model.running)
                if model.running { Text("请先断开连接再导入。").font(.caption).foregroundStyle(.orange) }
                if let error = model.banner { Text(error).font(.caption).foregroundStyle(.orange) }
                Text("暂不支持 Clash YAML。只在你点击导入后下载订阅，地址不会写入诊断记录。").font(.caption).foregroundStyle(.secondary)
                Spacer()
            }.padding(20).navigationTitle("导入线路").navigationBarTitleDisplayMode(.inline).toolbar { ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } } }
            .sheet(isPresented: $scanning) { QRScanner { value in text = value; scanning = false } }
        }.preferredColorScheme(.dark)
    }
}
