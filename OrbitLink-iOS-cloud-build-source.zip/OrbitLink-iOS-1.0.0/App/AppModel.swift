import Foundation
import SwiftUI
import NetworkExtension

@MainActor final class AppModel: ObservableObject {
    @Published var nodes: [Node] = []
    @Published var intent = Intent()
    @Published var snapshot = Snapshot()
    @Published var status: NEVPNStatus = .invalid
    @Published var banner: String? = nil
    @Published var importing = false
    @Published var uploadHistory: [Double] = []
    @Published var downloadHistory: [Double] = []
    private var manager: NETunnelProviderManager?
    private var observer: NSObjectProtocol?
    private var operations: Task<Void, Never>?
    private var revision = UUID()
    private var lastHistoryDate = Date.distantPast
    private var pendingChoice: ProviderRequest?
    private var lastErrorDate = Date.distantPast
    var running: Bool { [.connected, .connecting, .reasserting].contains(status) }
    var verified: Bool { status == .connected && snapshot.verified }
    var active: Node? { nodes.first { $0.id == snapshot.activeID } }
    var statusText: String {
        if status == .disconnecting { return "正在断开" }
        if !running { return "尚未连接" }
        if verified { return "安全连接已验证" }
        if snapshot.phase == "testing" { return "地区线路优选中" }
        if snapshot.phase == "offline" { return "等待可用网络" }
        if snapshot.phase == "degraded" { return "链路异常，正在恢复" }
        return "正在验证连接"
    }
    init() {
        observer = NotificationCenter.default.addObserver(forName: .NEVPNStatusDidChange, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor in self?.status = self?.manager?.connection.status ?? .invalid }
        }
        Task { await reload() }
    }
    func reload() async {
        do {
            nodes = try SharedFiles.load(Catalog.self, "catalog.json", fallback: Catalog()).nodes
            intent = try SharedFiles.load(Intent.self, "intent.json", fallback: Intent())
            snapshot = try SharedFiles.load(Snapshot.self, "snapshot.json", fallback: Snapshot())
            manager = try await existingManager(); status = manager?.connection.status ?? .invalid
        } catch { banner = error.localizedDescription }
    }
    private var providerID: String { (Bundle.main.bundleIdentifier ?? "com.orbitlink.ios") + ".PacketTunnel" }
    private func existingManager() async throws -> NETunnelProviderManager? {
        let list: [NETunnelProviderManager] = try await withCheckedThrowingContinuation { continuation in
            NETunnelProviderManager.loadAllFromPreferences { values, error in
                if let error { continuation.resume(throwing: error) } else { continuation.resume(returning: values ?? []) }
            }
        }
        return list.first { ($0.protocolConfiguration as? NETunnelProviderProtocol)?.providerBundleIdentifier == providerID }
    }
    private func save(_ manager: NETunnelProviderManager) async throws {
        try await withCheckedThrowingContinuation { (c: CheckedContinuation<Void, Error>) in manager.saveToPreferences { e in if let e { c.resume(throwing: e) } else { c.resume() } } }
        try await withCheckedThrowingContinuation { (c: CheckedContinuation<Void, Error>) in manager.loadFromPreferences { e in if let e { c.resume(throwing: e) } else { c.resume() } } }
    }
    func connect(region: String? = nil, node: Node? = nil) {
        guard !nodes.isEmpty else { banner = "请先导入订阅或节点"; return }
        let token = UUID(); revision = token
        let previous = operations
        operations = Task { [weak self] in
            await previous?.value
            guard let self, token == revision else { return }
            do {
                if let region { intent.region = region; intent.manualID = nil }
                if let node { intent.region = nil; intent.manualID = node.id }
                if intent.region == nil, intent.manualID == nil, let first = nodes.first {
                    if first.region != "未识别" { intent.region = first.region }
                    else { intent.manualID = first.id }
                }
                try SharedFiles.save(intent, "intent.json")
                if running, status == .connected {
                    if let region { try await send(.init(action: "region", region: region)) }
                    else if let node { try await send(.init(action: "manual", nodeID: node.id)) }
                    return
                }
                guard !running else {
                    if let region { pendingChoice = .init(action: "region", region: region) }
                    else if let node { pendingChoice = .init(action: "manual", nodeID: node.id) }
                    return
                }
                let selected = try await existingManager() ?? NETunnelProviderManager()
                guard token == revision else { return }
                let proto = NETunnelProviderProtocol(); proto.providerBundleIdentifier = providerID; proto.serverAddress = "OrbitLink"
                proto.disconnectOnSleep = false
                selected.protocolConfiguration = proto; selected.localizedDescription = "星枢 · OrbitLink"; selected.isEnabled = true
                let rule = NEOnDemandRuleConnect(); rule.interfaceTypeMatch = .any
                selected.onDemandRules = intent.onDemand ? [rule] : []; selected.isOnDemandEnabled = intent.onDemand
                manager = selected
                try await save(selected)
                guard token == revision else { return }
                guard let session = selected.connection as? NETunnelProviderSession else { throw OrbitError.message("系统 VPN 会话不可用") }
                snapshot = Snapshot(); snapshot.phase = "checking"
                try session.startTunnel(); status = session.status
            } catch { banner = "连接失败：" + error.localizedDescription; status = manager?.connection.status ?? .disconnected }
        }
    }
    func disconnect() {
        revision = UUID(); pendingChoice = nil; let previous = operations
        operations = Task { [weak self] in
            await previous?.value
            guard let self, let manager else { return }
            do {
                // Disable on-demand first so the system respects an explicit user stop.
                manager.isOnDemandEnabled = false; try await save(manager)
                manager.connection.stopVPNTunnel(); status = manager.connection.status
            } catch { banner = "停止失败：" + error.localizedDescription }
        }
    }
    private func reply(_ request: ProviderRequest) async throws -> ProviderReply {
        guard let session = manager?.connection as? NETunnelProviderSession, status == .connected else { throw OrbitError.message("VPN 尚未连接") }
        let data = try JSONEncoder().encode(request)
        return try await withCheckedThrowingContinuation { c in
            do {
                try session.sendProviderMessage(data) { response in
                    guard let response else { c.resume(throwing: OrbitError.message("VPN 扩展未返回状态")); return }
                    do { c.resume(returning: try JSONDecoder().decode(ProviderReply.self, from: response)) } catch { c.resume(throwing: error) }
                }
            } catch { c.resume(throwing: error) }
        }
    }
    private func send(_ request: ProviderRequest) async throws {
        let result = try await reply(request)
        if let error = result.error { throw OrbitError.message(error) }
        if let snapshot = result.snapshot { self.snapshot = snapshot }
    }
    func poll() async {
        status = manager?.connection.status ?? .invalid
        guard running else {
            if let state = try? SharedFiles.load(Snapshot.self, "snapshot.json", fallback: snapshot) {
                snapshot = state
                if state.phase == "error", state.updatedAt > lastErrorDate { lastErrorDate = state.updatedAt; banner = state.message }
            }
            return
        }
        do {
            if status == .connected {
                if let choice = pendingChoice { pendingChoice = nil; try await send(choice) }
                try await send(.init(action: "snapshot"))
            }
            else { snapshot = try SharedFiles.load(Snapshot.self, "snapshot.json", fallback: snapshot) }
            if lastHistoryDate != snapshot.updatedAt {
                lastHistoryDate = snapshot.updatedAt
                uploadHistory = Array((uploadHistory + [snapshot.upload]).suffix(60))
                downloadHistory = Array((downloadHistory + [snapshot.download]).suffix(60))
            }
            // The extension owns the chosen region and manual intent during a connection.
            if let value = try? SharedFiles.load(Intent.self, "intent.json", fallback: intent) { intent = value }
        } catch { /* Keep the last timestamp: old data is never presented as verified. */ }
    }
    func saveSettings() {
        guard !running else { banner = "连接期间请先断开，再修改恢复设置"; return }
        do { try SharedFiles.save(intent, "intent.json") } catch { banner = error.localizedDescription }
    }
    func importText(_ text: String) async -> Bool {
        guard !running else { banner = "请先断开，再更新节点"; return false }
        importing = true; defer { importing = false }
        do {
            var source = text.trimmingCharacters(in: .whitespacesAndNewlines)
            if source.lowercased().hasPrefix("https://") {
                guard let url = URL(string: source), url.user == nil, url.password == nil else { throw OrbitError.message("订阅地址无效") }
                let config = URLSessionConfiguration.ephemeral; config.timeoutIntervalForRequest = 20; config.timeoutIntervalForResource = 30
                let client = URLSession(configuration: config)
                defer { client.invalidateAndCancel() }
                var request = URLRequest(url: url); request.setValue("OrbitLink/1.0", forHTTPHeaderField: "User-Agent")
                let (bytes, response) = try await client.bytes(for: request)
                guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode), http.url?.scheme == "https" else { throw OrbitError.message("订阅下载失败，需要有效的 HTTPS 地址") }
                var data = Data()
                for try await byte in bytes { data.append(byte); if data.count > 8 * 1024 * 1024 { throw OrbitError.message("订阅超过 8 MB") } }
                guard let value = String(data: data, encoding: .utf8) else { throw OrbitError.message("订阅不是 UTF-8 文本") }
                source = value
            }
            let result = try NodeImporter.parse(source)
            var byID = Dictionary(uniqueKeysWithValues: nodes.map { ($0.id, $0) })
            for node in result.nodes { byID[node.id] = node }
            guard byID.count <= 1000 else { throw OrbitError.message("最多保留 1000 个节点，请先清空旧节点") }
            nodes = byID.values.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
            try SharedFiles.save(Catalog(nodes: nodes), "catalog.json")
            banner = "已导入 \(result.nodes.count) 个节点" + (result.rejected > 0 ? "，跳过 \(result.rejected) 个无效或不支持的条目" : "")
            return true
        } catch { banner = error.localizedDescription; return false }
    }
    func deleteNodes() {
        guard !running else { banner = "请先断开连接"; return }
        do { try SharedFiles.save(Catalog(), "catalog.json"); nodes = []; snapshot = Snapshot(); intent.region = nil; intent.manualID = nil; try SharedFiles.save(intent, "intent.json") }
        catch { banner = error.localizedDescription }
    }
    static func speed(_ bytes: Double) -> String {
        if bytes >= 1_048_576 { return String(format: "%.1f MB/s", bytes / 1_048_576) }
        return String(format: "%.1f KB/s", bytes / 1024)
    }
}
