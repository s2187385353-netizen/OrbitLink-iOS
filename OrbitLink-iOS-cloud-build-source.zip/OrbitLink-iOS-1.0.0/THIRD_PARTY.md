# Third-party sources

OrbitLink iOS development source is distributed under GPL-3.0-or-later. The original OrbitLink brand artwork is retained from this user's desktop project. No association with SagerNet or Apple is implied.

| Component | Fixed source | License | Use |
|---|---|---|---|
| sing-box / experimental/libbox | SagerNet/sing-box v1.14.3; commit `7054cac5124465ffdb145870d7c01885566711b1` | GPL-3.0-or-later, upstream name/association restriction retained | VPN engine, TUN, Clash-compatible local control API |
| Apple platform reference | SagerNet/sing-box-for-apple `e232aaf22d6d68773196ffc8e6e79684a6be717c`, the submodule revision pinned by that core release | GPL-3.0-or-later | `PacketTunnel/OrbitPlatform.swift` partly adapted; other application code independently implemented |
| sagernet/gomobile | v0.1.13 | BSD-3-Clause (see corresponding source) | Optional Mac build-time binding tool |
| Go | 1.26.8, matching upstream Apple workflow | BSD-3-Clause | Optional Mac compiler and linked runtime |

Core archive `Vendor/sing-box-v1.14.3.zip`, SHA-256 `5bf11eeb2f5b93377166af1ecdcf24dd2c4be3c92bcb43c09d95edd01eb85949`, was downloaded from https://codeload.github.com/SagerNet/sing-box/zip/refs/tags/v1.14.3. It contains the corresponding engine source, dependency versions and checksums in `go.mod` and `go.sum`. Engine dependencies carry their own licenses; preserve them when producing or distributing a binary. The framework is intentionally not presented as built in this delivery.

The original Apple platform files and license used for reference are included under `Vendor/AppleReference/`. They are not compiled into the app directly. Upstream build and installation scripts in these archives are source material; only the reviewed, explicit build commands in `scripts/` form this project's build path.

No original Windows/Android binary, subscriber configuration, private signing key or user subscription is included. Apple's NetworkExtension and SwiftUI are system SDKs supplied by Xcode; no Apple SDK is redistributed.

Sources:
- https://github.com/SagerNet/sing-box/tree/v1.14.3
- https://github.com/SagerNet/sing-box-for-apple/tree/e232aaf22d6d68773196ffc8e6e79684a6be717c
- https://github.com/SagerNet/gomobile/tree/v0.1.13
