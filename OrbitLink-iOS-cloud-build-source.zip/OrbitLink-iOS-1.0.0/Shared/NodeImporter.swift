import Foundation

struct ImportResult { var nodes: [Node] = []; var rejected = 0 }
enum NodeImporter {
    static func base64(_ text: String) -> String? {
        var s = text.trimmingCharacters(in: .whitespacesAndNewlines).replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        s += String(repeating: "=", count: (4 - s.count % 4) % 4)
        guard let data = Data(base64Encoded: s, options: .ignoreUnknownCharacters) else { return nil }
        return String(data: data, encoding: .utf8)
    }
    static func parse(_ input: String) throws -> ImportResult {
        guard input.utf8.count <= 8 * 1024 * 1024 else { throw OrbitError.message("导入内容超过 8 MB") }
        let source = input.trimmingCharacters(in: .whitespacesAndNewlines)
        var result = ImportResult()
        if source.first == "{" || source.first == "[" {
            let json = try JSONDecoder().decode(JSONValue.self, from: Data(source.utf8))
            let list: [JSONValue]
            if case .array(let values) = json { list = values }
            else if case .array(let values)? = json.object?["outbounds"] { list = values }
            else { list = [json] }
            for value in list {
                guard let ob = value.object, Node.supported.contains(ob["type"]?.string ?? "") else { result.rejected += 1; continue }
                do { result.nodes.append(try Node(name: ob["tag"]?.string ?? "未命名节点", outbound: ob)) }
                catch { result.rejected += 1 }
            }
        } else {
            let text = source.contains("://") ? source : (base64(source) ?? source)
            for line in text.components(separatedBy: .newlines).map({ $0.trimmingCharacters(in: .whitespacesAndNewlines) }) where !line.isEmpty && !line.hasPrefix("#") {
                do { result.nodes.append(try link(line)) } catch { result.rejected += 1 }
                if result.nodes.count > 1000 { throw OrbitError.message("单次最多导入 1000 个节点") }
            }
        }
        var seen = Set<String>(); result.nodes = result.nodes.filter { seen.insert($0.id).inserted }
        guard !result.nodes.isEmpty else { throw OrbitError.message("没有可用节点。支持分享链接、Base64 订阅和 sing-box JSON；暂不支持 Clash YAML。") }
        guard result.nodes.count <= 1000 else { throw OrbitError.message("单次最多导入 1000 个节点") }
        return result
    }
    private static func link(_ source: String) throws -> Node {
        if source.lowercased().hasPrefix("vmess://") { return try vmess(String(source.dropFirst(8))) }
        var link = source
        if source.lowercased().hasPrefix("ss://"), !source.contains("@") {
            let parts = String(source.dropFirst(5)).components(separatedBy: "#")
            guard let decoded = base64(parts[0]) else { throw OrbitError.message("SS 编码无效") }
            link = "ss://" + decoded + (parts.count > 1 ? "#" + parts[1] : "")
        }
        guard let c = URLComponents(string: link), let scheme = c.scheme?.lowercased(), let host = c.host else { throw OrbitError.message("分享链接无效") }
        var q: [String: String] = [:]
        for item in c.queryItems ?? [] { q[item.name.lowercased()] = item.value ?? "" }
        let type = ["ss": "shadowsocks", "hy2": "hysteria2"][scheme] ?? scheme
        guard Node.supported.contains(type), type != "tuic" else { throw OrbitError.message("此分享格式尚未支持") }
        var ob: [String: JSONValue] = ["type": .string(type), "server": .string(host), "server_port": .number(Double(c.port ?? (type == "hysteria2" ? 443 : 0)))]
        switch type {
        case "vless": ob["uuid"] = .string(c.user ?? ""); if let flow = q["flow"], !flow.isEmpty { ob["flow"] = .string(flow) }
        case "trojan", "hysteria2": ob["password"] = .string(c.user ?? "")
        case "shadowsocks":
            guard q["plugin"] == nil else { throw OrbitError.message("暂不支持 SS 插件") }
            let auth = c.password.map { (c.user ?? "") + ":" + $0 } ?? base64(c.user ?? "") ?? ""
            let parts = auth.split(separator: ":", maxSplits: 1, omittingEmptySubsequences: false)
            guard parts.count == 2 else { throw OrbitError.message("SS 密钥无效") }
            ob["method"] = .string(String(parts[0])); ob["password"] = .string(String(parts[1]))
        default: throw OrbitError.message("分享链接协议未支持")
        }
        if type == "vless" { guard UUID(uuidString: c.user ?? "") != nil else { throw OrbitError.message("UUID 无效") } }
        if type != "shadowsocks" {
            let security = q["security"] ?? (type == "vless" ? "none" : "tls")
            if security == "tls" || security == "reality" {
                var tls: [String: JSONValue] = ["enabled": .bool(true), "server_name": .string(q["sni"] ?? q["peer"] ?? host)]
                if let alpn = q["alpn"], !alpn.isEmpty { tls["alpn"] = .array(alpn.components(separatedBy: ",").map(JSONValue.string)) }
                if q["allowinsecure"] == "1" || q["insecure"] == "1" { tls["insecure"] = .bool(true) }
                if let fp = q["fp"], !fp.isEmpty { tls["utls"] = .object(["enabled": .bool(true), "fingerprint": .string(fp)]) }
                if security == "reality" {
                    guard let key = q["pbk"], !key.isEmpty else { throw OrbitError.message("Reality 公钥缺失") }
                    tls["reality"] = .object(["enabled": .bool(true), "public_key": .string(key), "short_id": .string(q["sid"] ?? "")])
                    if tls["utls"] == nil { tls["utls"] = .object(["enabled": .bool(true), "fingerprint": .string("chrome")]) }
                }
                ob["tls"] = .object(tls)
            } else if security != "none" && !security.isEmpty { throw OrbitError.message("此安全模式尚未支持") }
            if let transport = q["type"], !transport.isEmpty, transport != "tcp" {
                switch transport {
                case "ws", "httpupgrade": ob["transport"] = .object(["type": .string(transport), "path": .string(q["path"] ?? "/"), "headers": .object(["Host": .string(q["host"] ?? q["sni"] ?? host)])])
                case "grpc": ob["transport"] = .object(["type": .string("grpc"), "service_name": .string(q["servicename"] ?? "")])
                default: throw OrbitError.message("此传输模式尚未支持")
                }
            }
            if type == "hysteria2", let mode = q["obfs"], !mode.isEmpty {
                guard mode == "salamander", let password = q["obfs-password"] else { throw OrbitError.message("HY2 混淆参数无效") }
                ob["obfs"] = .object(["type": .string(mode), "password": .string(password)])
            }
        }
        return try Node(name: c.fragment ?? "未命名节点", outbound: ob)
    }
    private static func vmess(_ payload: String) throws -> Node {
        guard let text = base64(payload), let data = text.data(using: .utf8),
              let v = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              let host = v["add"] as? String, let uuid = v["id"] as? String, UUID(uuidString: uuid) != nil else { throw OrbitError.message("VMess 编码无效") }
        func s(_ key: String) -> String { v[key].map { String(describing: $0) } ?? "" }
        guard s("aid").isEmpty || s("aid") == "0" else { throw OrbitError.message("不支持旧式 VMess alterId") }
        var ob: [String: JSONValue] = ["type": .string("vmess"), "server": .string(host), "server_port": .number(Double(s("port")) ?? 0), "uuid": .string(uuid), "security": .string(s("scy").isEmpty ? "auto" : s("scy"))]
        if s("tls") == "tls" { ob["tls"] = .object(["enabled": .bool(true), "server_name": .string(s("sni").isEmpty ? host : s("sni"))]) }
        switch s("net") {
        case "ws": ob["transport"] = .object(["type": .string("ws"), "path": .string(s("path").isEmpty ? "/" : s("path")), "headers": .object(["Host": .string(s("host").isEmpty ? host : s("host"))])])
        case "grpc": ob["transport"] = .object(["type": .string("grpc"), "service_name": .string(s("path"))])
        case "", "tcp": guard s("type").isEmpty || s("type") == "none" else { throw OrbitError.message("不支持此 VMess 伪装") }
        default: throw OrbitError.message("不支持此 VMess 传输")
        }
        return try Node(name: s("ps"), outbound: ob)
    }
}
