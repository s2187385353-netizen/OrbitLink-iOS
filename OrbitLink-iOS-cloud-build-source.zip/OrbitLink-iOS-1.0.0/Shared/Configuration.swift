import Foundation

enum Configuration {
    static func make(nodes: [Node], active: Node, secret: String, port: Int) throws -> String {
        guard !nodes.isEmpty, nodes.contains(where: { $0.id == active.id }) else { throw OrbitError.message("所选节点已不存在") }
        var outbounds = nodes.map { node -> JSONValue in
            var ob = node.outbound; ob["tag"] = .string(node.tag); return .object(ob)
        }
        outbounds.insert(.object(["type": .string("selector"), "tag": .string("orbit"), "outbounds": .array(nodes.map { .string($0.tag) }), "default": .string(active.tag), "interrupt_exist_connections": .bool(true)]), at: 0)
        outbounds.append(.object(["type": .string("direct"), "tag": .string("direct")]))
        let config: JSONValue = .object([
            "log": .object(["level": .string("warn"), "timestamp": .bool(true)]),
            "dns": .object(["servers": .array([
                .object(["type": .string("udp"), "tag": .string("bootstrap"), "server": .string("223.5.5.5"), "server_port": .number(53), "detour": .string("direct")]),
                .object(["type": .string("https"), "tag": .string("remote"), "server": .string("1.1.1.1"), "server_port": .number(443), "path": .string("/dns-query"), "detour": .string("orbit")])
            ]), "final": .string("remote"), "strategy": .string("prefer_ipv4")]),
            "inbounds": .array([.object(["type": .string("tun"), "tag": .string("tun"), "address": .array([.string("172.19.0.1/30"), .string("fdfe:dcba:9876::1/126")]), "mtu": .number(1400), "auto_route": .bool(true), "dns_mode": .string("hijack"), "stack": .string("mixed")])]),
            "outbounds": .array(outbounds),
            "route": .object(["auto_detect_interface": .bool(true), "default_domain_resolver": .string("bootstrap"), "final": .string("orbit"), "rules": .array([
                .object(["action": .string("sniff")]),
                .object(["protocol": .string("dns"), "action": .string("hijack-dns")]),
                .object(["ip_is_private": .bool(true), "action": .string("route"), "outbound": .string("direct")])
            ])]),
            "experimental": .object(["clash_api": .object(["external_controller": .string("127.0.0.1:\(port)"), "secret": .string(secret), "default_mode": .string("rule")])])
        ])
        let data = try JSONEncoder().encode(config)
        return String(decoding: data, as: UTF8.self)
    }
}
