import Foundation

// iOS container / file protection APIs are kept out of the Mac-only logic test target.
enum SharedFiles {
    static func directory() throws -> URL {
        guard let group = Bundle.main.object(forInfoDictionaryKey: "OrbitAppGroup") as? String,
              let url = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) else {
            throw OrbitError.message("共享容器不可用，请检查两个目标的 App Groups 签名")
        }
        return url
    }
    static func load<T: Decodable>(_ type: T.Type, _ name: String, fallback: T) throws -> T {
        let url = try directory().appendingPathComponent(name)
        guard FileManager.default.fileExists(atPath: url.path) else { return fallback }
        return try JSONDecoder().decode(type, from: Data(contentsOf: url))
    }
    static func save<T: Encodable>(_ value: T, _ name: String) throws {
        var url = try directory().appendingPathComponent(name)
        try JSONEncoder().encode(value).write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        var values = URLResourceValues(); values.isExcludedFromBackup = true
        try url.setResourceValues(values)
    }
}
