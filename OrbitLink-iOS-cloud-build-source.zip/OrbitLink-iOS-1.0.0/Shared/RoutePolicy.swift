import Foundation

enum Regions {
    static let primary = ["日本", "美国", "新加坡", "台湾"]
    static let all = primary + ["香港", "未识别"]
    static func resolve(_ name: String) -> String {
        let n = name.lowercased()
        let aliases: [(String, [String])] = [
            ("日本", ["日本", "东京", "大阪", "japan", "tokyo", "osaka", "🇯🇵"]),
            ("美国", ["美国", "洛杉矶", "纽约", "圣何塞", "united states", "los angeles", "new york", "san jose", "🇺🇸"]),
            ("新加坡", ["新加坡", "singapore", "狮城", "🇸🇬"]),
            ("台湾", ["台湾", "臺灣", "台北", "臺北", "taiwan", "taipei", "🇹🇼"]),
            ("香港", ["香港", "hong kong", "🇭🇰"])]
        for (region, words) in aliases where words.contains(where: n.contains) { return region }
        for (code, region) in [("jp", "日本"), ("us", "美国"), ("sg", "新加坡"), ("tw", "台湾"), ("hk", "香港")] {
            if n.range(of: "(^|[^a-z])\(code)(?=[^a-z]|$)", options: .regularExpression) != nil { return region }
        }
        return "未识别"
    }
}

struct Quality: Codable, Equatable {
    var samples: [Int] = []; var testedAt: TimeInterval = 0
    var good: [Int] { samples.filter { $0 >= 0 }.sorted() }
    var success: Double { samples.isEmpty ? 0 : Double(good.count) / Double(samples.count) }
    var median: Int { good.isEmpty ? Int.max : good[good.count / 2] }
    var jitter: Int { good.isEmpty ? Int.max : good.last! - good.first! }
    var score: Double { good.isEmpty ? 0 : success * 100 - min(Double(median) / 20, 25) - min(Double(jitter) / 8, 15) }
    func usable(now: TimeInterval) -> Bool {
        samples.count >= 3 && success >= 2.0 / 3 && testedAt > 0 && now >= testedAt && now - testedAt < 300
    }
}

enum RoutePolicy {
    static func rank(_ nodes: [Node], region: String, quality: [String: Quality], blocked: [String: TimeInterval],
                     now: TimeInterval, excluding: String? = nil) -> [Node] {
        nodes.filter { $0.region == region && $0.id != excluding && (blocked[$0.id] ?? 0) <= now && quality[$0.id]?.usable(now: now) == true }
            .sorted {
                let a = quality[$0.id]!, b = quality[$1.id]!
                if a.score != b.score { return a.score > b.score }
                if a.jitter != b.jitter { return a.jitter < b.jitter }
                if a.median != b.median { return a.median < b.median }
                return $0.id < $1.id
            }
    }
}

struct RecoveryBudget {
    private(set) var failures = 0
    private var lastSwitch: TimeInterval? = nil
    private var switches: [TimeInterval] = []
    mutating func healthy() { failures = 0 }
    mutating func failed() { failures = min(failures + 1, 1000) }
    mutating func canSwitch(now: TimeInterval) -> Bool {
        switches.removeAll { now - $0 >= 600 || now < $0 }
        return failures >= 3 && (lastSwitch == nil || now - lastSwitch! >= 90) && switches.count < 3
    }
    mutating func switched(now: TimeInterval) { lastSwitch = now; switches.append(now); failures = 0 }
}
