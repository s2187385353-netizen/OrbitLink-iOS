import Foundation
import CryptoKit

enum OrbitError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let text) = self { return text }; return nil }
}

enum JSONValue: Codable, Equatable {
    case string(String), number(Double), bool(Bool), object([String: JSONValue]), array([JSONValue]), null
    init(from decoder: Decoder) throws {
        let c = try decoder.singleValueContainer()
        if c.decodeNil() { self = .null }
        else if let v = try? c.decode(Bool.self) { self = .bool(v) }
        else if let v = try? c.decode(Double.self) { self = .number(v) }
        else if let v = try? c.decode(String.self) { self = .string(v) }
        else if let v = try? c.decode([String: JSONValue].self) { self = .object(v) }
        else { self = .array(try c.decode([JSONValue].self)) }
    }
    func encode(to encoder: Encoder) throws {
        var c = encoder.singleValueContainer()
        switch self {
        case .string(let v): try c.encode(v)
        case .number(let v): try c.encode(v)
        case .bool(let v): try c.encode(v)
        case .object(let v): try c.encode(v)
        case .array(let v): try c.encode(v)
        case .null: try c.encodeNil()
        }
    }
    var string: String? { if case .string(let v) = self { return v }; return nil }
    var object: [String: JSONValue]? { if case .object(let v) = self { return v }; return nil }
    var number: Double? { if case .number(let v) = self { return v }; return nil }
}

struct Node: Codable, Identifiable, Equatable {
    let id: String
    var name: String
    var region: String
    var outbound: [String: JSONValue]
    static let supported = ["vless", "vmess", "trojan", "shadowsocks", "hysteria2", "tuic"]
    init(name: String, outbound: [String: JSONValue]) throws {
        guard let type = outbound["type"]?.string, Self.supported.contains(type),
              let host = outbound["server"]?.string, !host.isEmpty,
              let port = outbound["server_port"]?.number, port >= 1, port <= 65535, port.rounded() == port else {
            throw OrbitError.message("节点的协议、服务器或端口无效")
        }
        if ["vless", "vmess", "tuic"].contains(type), UUID(uuidString: outbound["uuid"]?.string ?? "") == nil { throw OrbitError.message("节点 UUID 无效") }
        if ["trojan", "tuic"].contains(type), outbound["password"]?.string?.isEmpty != false { throw OrbitError.message("节点密码缺失") }
        if type == "shadowsocks", outbound["method"]?.string?.isEmpty != false { throw OrbitError.message("SS 加密方法缺失") }
        var clean = outbound
        clean.removeValue(forKey: "tag")
        // Each imported outbound must dial its own server, never an injected local detour.
        clean.removeValue(forKey: "detour")
        let encoder = JSONEncoder(); encoder.outputFormatting = .sortedKeys
        id = SHA256.hash(data: try encoder.encode(clean)).map { String(format: "%02x", $0) }.joined()
        self.name = name.isEmpty ? "未命名节点" : String(name.prefix(160))
        region = Regions.resolve(self.name)
        self.outbound = clean
    }
    var tag: String { "node-" + String(id.prefix(24)) }
    var type: String { outbound["type"]?.string?.uppercased() ?? "" }
}

struct Catalog: Codable { var nodes: [Node] = [] }
struct Intent: Codable {
    var region: String? = nil
    var manualID: String? = nil
    var automaticRecovery = true
    var onDemand = false
    var animations = true
}
struct RouteEvent: Codable, Identifiable {
    var id = UUID(); var time = Date(); let text: String
}
struct Snapshot: Codable {
    var updatedAt = Date(timeIntervalSince1970: 0)
    var phase = "disconnected"
    var message = "尚未连接"
    var activeID: String? = nil
    var region: String? = nil
    var latency: Int? = nil
    var failures = 0
    var upload: Double = 0; var download: Double = 0
    var totalUpload: Double = 0; var totalDownload: Double = 0
    var qualities: [String: Quality] = [:]
    var blockedUntil: [String: TimeInterval] = [:]
    var events: [RouteEvent] = []
    var verified: Bool { phase == "connected" && Date().timeIntervalSince(updatedAt) < 45 }
}
struct ProviderRequest: Codable { let action: String; var region: String? = nil; var nodeID: String? = nil }
struct ProviderReply: Codable { var error: String? = nil; var snapshot: Snapshot? = nil }

