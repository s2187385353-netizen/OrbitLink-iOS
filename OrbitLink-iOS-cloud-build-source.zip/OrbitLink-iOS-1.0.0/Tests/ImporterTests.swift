import XCTest
@testable import OrbitLogic

final class ImporterTests: XCTestCase {
    let uuid = "11111111-1111-4111-8111-111111111111"
    func testVlessTLSWebSocketAndRegion() throws {
        let nodes = try NodeImporter.parse("vless://\(uuid)@example.invalid:443?security=tls&type=ws&host=cdn.invalid&path=%2Fws#SG新加坡01").nodes
        XCTAssertEqual(nodes.count, 1); XCTAssertEqual(nodes[0].region, "新加坡")
        XCTAssertEqual(nodes[0].outbound["tls"]?.object?["enabled"], .bool(true))
        XCTAssertEqual(nodes[0].outbound["transport"]?.object?["path"], .string("/ws"))
    }
    func testRealityRequiresPublicKey() throws {
        XCTAssertThrowsError(try NodeImporter.parse("vless://\(uuid)@example.invalid:443?security=reality#SG"))
        let node = try NodeImporter.parse("vless://\(uuid)@example.invalid:443?security=reality&pbk=testkey&sid=01#SG").nodes[0]
        XCTAssertEqual(node.outbound["tls"]?.object?["reality"]?.object?["public_key"], .string("testkey"))
    }
    func testBase64SubscriptionAndDeduplication() throws {
        let text = "vless://\(uuid)@example.invalid:443#日本01\nvless://\(uuid)@example.invalid:443#日本02"
        let result = try NodeImporter.parse(Data(text.utf8).base64EncodedString())
        XCTAssertEqual(result.nodes.count, 1)
    }
    func testShadowsocksPasswordCanContainColon() throws {
        let auth = Data("aes-256-gcm:pass:word".utf8).base64EncodedString()
        let node = try NodeImporter.parse("ss://\(auth)@example.invalid:443#台湾01").nodes[0]
        XCTAssertEqual(node.outbound["password"], .string("pass:word"))
    }
    func testVMessTLS() throws {
        let json = "{\"v\":\"2\",\"ps\":\"美国01\",\"add\":\"example.invalid\",\"port\":443,\"id\":\"\(uuid)\",\"aid\":0,\"net\":\"ws\",\"path\":\"/ws\",\"tls\":\"tls\"}"
        let node = try NodeImporter.parse("vmess://" + Data(json.utf8).base64EncodedString()).nodes[0]
        XCTAssertEqual(node.region, "美国"); XCTAssertEqual(node.outbound["tls"]?.object?["enabled"], .bool(true))
    }
    func testInvalidPortAndUnsupportedFormat() {
        XCTAssertThrowsError(try NodeImporter.parse("vless://\(uuid)@example.invalid:0#SG"))
        XCTAssertThrowsError(try NodeImporter.parse("proxies:\n - name: SG"))
        XCTAssertThrowsError(try NodeImporter.parse("vless://bad@host.invalid:443#SG"))
    }
    func testJSONDiscardsSelectorAndInjectedDetour() throws {
        let result = try NodeImporter.parse("{\"outbounds\":[{\"type\":\"selector\",\"tag\":\"group\"},{\"type\":\"vless\",\"tag\":\"新加坡\",\"server\":\"example.invalid\",\"server_port\":443,\"uuid\":\"\(uuid)\",\"detour\":\"direct\"}]}")
        XCTAssertEqual(result.nodes.count, 1); XCTAssertNil(result.nodes[0].outbound["detour"]); XCTAssertEqual(result.rejected, 1)
    }
    func testConfigurationUsesAuthenticatedLoopbackAndRealNodes() throws {
        let node = try NodeImporter.parse("vless://\(uuid)@example.invalid:443#SG").nodes[0]
        let text = try Configuration.make(nodes: [node], active: node, secret: "test-secret", port: 23456)
        let json = try JSONDecoder().decode(JSONValue.self, from: Data(text.utf8))
        XCTAssertEqual(json.object?["experimental"]?.object?["clash_api"]?.object?["external_controller"], .string("127.0.0.1:23456"))
        XCTAssertEqual(json.object?["experimental"]?.object?["clash_api"]?.object?["secret"], .string("test-secret"))
        XCTAssertThrowsError(try Configuration.make(nodes: [], active: node, secret: "test", port: 23456))
    }
}
