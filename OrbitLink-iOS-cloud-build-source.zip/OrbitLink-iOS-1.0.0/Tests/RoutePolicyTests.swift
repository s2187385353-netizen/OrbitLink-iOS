import XCTest
@testable import OrbitLogic

final class RoutePolicyTests: XCTestCase {
    private func node(_ name: String, server: String = "example.invalid") throws -> Node {
        try Node(name: name, outbound: ["type": .string("vless"), "server": .string(server), "server_port": .number(443), "uuid": .string("11111111-1111-4111-8111-111111111111")])
    }
    func testRegionAliasesAndFalsePositive() {
        for name in ["SG新加坡01", "新加坡优选", "🇸🇬 02", "singapore 03"] { XCTAssertEqual(Regions.resolve(name), "新加坡") }
        XCTAssertEqual(Regions.resolve("JP东京01"), "日本")
        XCTAssertEqual(Regions.resolve("US 洛杉矶"), "美国")
        XCTAssertEqual(Regions.resolve("臺北線路"), "台湾")
        XCTAssertEqual(Regions.resolve("香港 01"), "香港")
        XCTAssertEqual(Regions.resolve("australia"), "未识别")
    }
    func testQualityRequiresThreeSamplesAndMajority() {
        XCTAssertFalse(Quality(samples: [50, 50], testedAt: 100).usable(now: 101))
        XCTAssertFalse(Quality(samples: [50, -1, -1], testedAt: 100).usable(now: 101))
        XCTAssertTrue(Quality(samples: [50, 60, -1], testedAt: 100).usable(now: 101))
    }
    func testStaleFutureAndRebootSamplesAreRejected() {
        let q = Quality(samples: [30, 31, 32], testedAt: 100)
        XCTAssertTrue(q.usable(now: 399)); XCTAssertFalse(q.usable(now: 400)); XCTAssertFalse(q.usable(now: 99))
    }
    func testStableSlowNodeBeatsFlakyFastNode() throws {
        let stable = try node("新加坡稳定", server: "a.invalid"), flaky = try node("新加坡快", server: "b.invalid")
        let quality = [stable.id: Quality(samples: [100, 101, 102], testedAt: 100), flaky.id: Quality(samples: [10, 11, -1], testedAt: 100)]
        XCTAssertEqual(RoutePolicy.rank([flaky, stable], region: "新加坡", quality: quality, blocked: [:], now: 101).first?.id, stable.id)
    }
    func testOtherRegionsQuarantineAndActiveAreExcluded() throws {
        let sg = try node("SG01", server: "a.invalid"), jp = try node("JP01", server: "b.invalid")
        let quality = [sg.id: Quality(samples: [50, 50, 50], testedAt: 100), jp.id: Quality(samples: [10, 10, 10], testedAt: 100)]
        XCTAssertEqual(RoutePolicy.rank([sg, jp], region: "新加坡", quality: quality, blocked: [:], now: 101).map(\.id), [sg.id])
        XCTAssertTrue(RoutePolicy.rank([sg, jp], region: "新加坡", quality: quality, blocked: [sg.id: 200], now: 101).isEmpty)
        XCTAssertTrue(RoutePolicy.rank([sg], region: "新加坡", quality: quality, blocked: [:], now: 101, excluding: sg.id).isEmpty)
    }
    func testThreeConsecutiveFailuresAndHealthyReset() {
        var b = RecoveryBudget(); b.failed(); b.failed(); XCTAssertFalse(b.canSwitch(now: 100))
        b.healthy(); b.failed(); XCTAssertFalse(b.canSwitch(now: 101)); b.failed(); b.failed(); XCTAssertTrue(b.canSwitch(now: 102))
    }
    func testCooldownAndSlidingWindow() {
        var b = RecoveryBudget()
        for t in [100.0, 200, 300] { b.failed(); b.failed(); b.failed(); XCTAssertTrue(b.canSwitch(now: t)); b.switched(now: t) }
        b.failed(); b.failed(); b.failed(); XCTAssertFalse(b.canSwitch(now: 389)); XCTAssertFalse(b.canSwitch(now: 600)); XCTAssertTrue(b.canSwitch(now: 701))
    }
}
