"""Generate the checked-in Xcode project without requiring a package manager on macOS."""
from pathlib import Path
import plistlib, json, hashlib, shutil

root = Path(__file__).resolve().parents[1]
objects = {}
def uid(label): return hashlib.sha256(label.encode()).hexdigest()[:24].upper()
def add(label, isa, **values):
    key = uid(label); assert key not in objects
    objects[key] = dict(isa=isa, **values); return key
def file(path, kind): return add('file:' + path, 'PBXFileReference', path=path, lastKnownFileType=kind, sourceTree='SOURCE_ROOT')
def build(label, ref, **values): return add('build:' + label, 'PBXBuildFile', fileRef=ref, **values)
def phase(label, isa, files, **values): return add(label, isa, buildActionMask=2147483647, files=files, runOnlyForDeploymentPostprocessing=0, **values)
def plist(path, data):
    p=root/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(plistlib.dumps(data,sort_keys=False))

common = dict(CFBundleDevelopmentRegion='zh_CN', CFBundleExecutable='$(EXECUTABLE_NAME)', CFBundleIdentifier='$(PRODUCT_BUNDLE_IDENTIFIER)', CFBundleInfoDictionaryVersion='6.0', CFBundleName='$(PRODUCT_NAME)', CFBundleShortVersionString='$(MARKETING_VERSION)', CFBundleVersion='$(CURRENT_PROJECT_VERSION)', OrbitAppGroup='$(APP_GROUP_IDENTIFIER)')
plist('App/Info.plist',dict(common,CFBundlePackageType='APPL',CFBundleDisplayName='星枢',LSRequiresIPhoneOS=True,UILaunchScreen={},UISupportedInterfaceOrientations=['UIInterfaceOrientationPortrait'],NSCameraUsageDescription='用于扫描你选择导入的节点二维码。',NSAppTransportSecurity={'NSAllowsLocalNetworking':True}))
plist('PacketTunnel/Info.plist',dict(common,CFBundlePackageType='XPC!',CFBundleDisplayName='OrbitLink VPN',NSExtension={'NSExtensionPointIdentifier':'com.apple.networkextension.packet-tunnel','NSExtensionPrincipalClass':'$(PRODUCT_MODULE_NAME).PacketTunnelProvider'},NSAppTransportSecurity={'NSAllowsLocalNetworking':True}))
entitlements={'com.apple.developer.networking.networkextension':['packet-tunnel-provider'],'com.apple.security.application-groups':['$(APP_GROUP_IDENTIFIER)']}
for target in ['App','PacketTunnel']: plist(target+'/'+target+'.entitlements',entitlements)

refs=[]; shared=[]; app=[]; extension=[]
for p in sorted(root.rglob('*.swift')):
    rel=p.relative_to(root).as_posix()
    if rel.startswith(('Shared/','App/','PacketTunnel/')):
        ref=file(rel,'sourcecode.swift');refs.append(ref)
        if rel.startswith('Shared/'): shared.append((rel,ref))
        elif rel.startswith('App/'): app.append((rel,ref))
        else: extension.append((rel,ref))
config=file('Configuration/Project.xcconfig','text.xcconfig');refs.append(config)
for name in ['App/Info.plist','App/App.entitlements','PacketTunnel/Info.plist','PacketTunnel/PacketTunnel.entitlements']:
    refs.append(file(name,'text.plist.xml'))
assets=file('App/Assets.xcassets','folder.assetcatalog');refs.append(assets)
lib=file('Frameworks/Libbox.xcframework','wrapper.xcframework');refs.append(lib)
resolv=add('resolv','PBXFileReference',lastKnownFileType='sourcecode.text-based-dylib-definition',name='libresolv.tbd',path='usr/lib/libresolv.tbd',sourceTree='SDKROOT');refs.append(resolv)
product_app=add('product-app','PBXFileReference',explicitFileType='wrapper.application',path='OrbitLink.app',sourceTree='BUILT_PRODUCTS_DIR')
product_ext=add('product-ext','PBXFileReference',explicitFileType='wrapper.app-extension',path='PacketTunnel.appex',sourceTree='BUILT_PRODUCTS_DIR')
products=add('products','PBXGroup',children=[product_app,product_ext],name='Products',sourceTree='<group>')
group=add('main-group','PBXGroup',children=refs+[products],sourceTree='<group>')

def configs(label, settings):
    values=[]
    for name in ['Debug','Release']:
        opts=dict(settings)
        if name=='Debug': opts.update(SWIFT_OPTIMIZATION_LEVEL='-Onone',SWIFT_ACTIVE_COMPILATION_CONDITIONS='DEBUG')
        else: opts.update(SWIFT_OPTIMIZATION_LEVEL='-O',DEBUG_INFORMATION_FORMAT='dwarf-with-dsym')
        values.append(add(label+name,'XCBuildConfiguration',baseConfigurationReference=config,buildSettings=opts,name=name))
    return add(label+'list','XCConfigurationList',buildConfigurations=values,defaultConfigurationIsVisible=0,defaultConfigurationName='Release')
project_configs=configs('project-',dict(CLANG_ENABLE_MODULES='YES',SDKROOT='iphoneos',SUPPORTED_PLATFORMS='iphoneos iphonesimulator',SWIFT_VERSION='5.0',IPHONEOS_DEPLOYMENT_TARGET='16.0'))
app_configs=configs('app-',dict(PRODUCT_BUNDLE_IDENTIFIER='$(APP_IDENTIFIER)',PRODUCT_NAME='OrbitLink',INFOPLIST_FILE='App/Info.plist',GENERATE_INFOPLIST_FILE='NO',CODE_SIGN_ENTITLEMENTS='App/App.entitlements',ASSETCATALOG_COMPILER_APPICON_NAME='AppIcon',LD_RUNPATH_SEARCH_PATHS=['$(inherited)','@executable_path/Frameworks']))
ext_configs=configs('ext-',dict(PRODUCT_BUNDLE_IDENTIFIER='$(APP_IDENTIFIER).PacketTunnel',PRODUCT_NAME='PacketTunnel',PRODUCT_MODULE_NAME='PacketTunnel',INFOPLIST_FILE='PacketTunnel/Info.plist',GENERATE_INFOPLIST_FILE='NO',CODE_SIGN_ENTITLEMENTS='PacketTunnel/PacketTunnel.entitlements',APPLICATION_EXTENSION_API_ONLY='YES',SKIP_INSTALL='YES',LD_RUNPATH_SEARCH_PATHS=['$(inherited)','@executable_path/Frameworks','@executable_path/../../Frameworks']))

app_sources=phase('app-sources','PBXSourcesBuildPhase',[build('app-'+n,r) for n,r in shared+app])
ext_sources=phase('ext-sources','PBXSourcesBuildPhase',[build('ext-'+n,r) for n,r in shared+extension])
app_resources=phase('app-resources','PBXResourcesBuildPhase',[build('assets',assets)])
ext_resources=phase('ext-resources','PBXResourcesBuildPhase',[])
app_frameworks=phase('app-frameworks','PBXFrameworksBuildPhase',[])
ext_frameworks=phase('ext-frameworks','PBXFrameworksBuildPhase',[build('libbox',lib),build('resolv',resolv)])
embed=phase('embed-extension','PBXCopyFilesBuildPhase',[build('embed',product_ext,settings={'ATTRIBUTES':['RemoveHeadersOnCopy']})],dstPath='',dstSubfolderSpec=13,name='Embed App Extensions')
check=add('check-core','PBXShellScriptBuildPhase',buildActionMask=2147483647,files=[],inputPaths=['$(SRCROOT)/Frameworks/Libbox.xcframework/Info.plist'],outputPaths=[],runOnlyForDeploymentPostprocessing=0,shellPath='/bin/bash',shellScript='test -f "$SRCROOT/Frameworks/Libbox.xcframework/Info.plist" || { echo "error: Run bash scripts/build-core.sh on macOS first"; exit 1; }',name='Check native VPN core')
target_ext=add('target-ext','PBXNativeTarget',buildConfigurationList=ext_configs,buildPhases=[check,ext_sources,ext_frameworks,ext_resources],buildRules=[],dependencies=[],name='PacketTunnel',productName='PacketTunnel',productReference=product_ext,productType='com.apple.product-type.app-extension')
project_id=uid('project')
proxy=add('proxy-ext','PBXContainerItemProxy',containerPortal=project_id,proxyType=1,remoteGlobalIDString=target_ext,remoteInfo='PacketTunnel')
dependency=add('dependency-ext','PBXTargetDependency',target=target_ext,targetProxy=proxy)
target_app=add('target-app','PBXNativeTarget',buildConfigurationList=app_configs,buildPhases=[app_sources,app_frameworks,app_resources,embed],buildRules=[],dependencies=[dependency],name='OrbitLink',productName='OrbitLink',productReference=product_app,productType='com.apple.product-type.application')
add('project','PBXProject',attributes={'BuildIndependentTargetsInParallel':'YES','LastUpgradeCheck':'1600','TargetAttributes':{target_app:{'CreatedOnToolsVersion':'16.0'},target_ext:{'CreatedOnToolsVersion':'16.0'}}},buildConfigurationList=project_configs,compatibilityVersion='Xcode 14.0',developmentRegion='zh_CN',hasScannedForEncodings=0,knownRegions=['en','zh_CN','Base'],mainGroup=group,productRefGroup=products,projectDirPath='',projectRoot='',targets=[target_app,target_ext])
graph=dict(archiveVersion=1,classes={},objectVersion=56,objects=objects,rootObject=project_id)
def ascii_plist(v, level=0):
    if isinstance(v,dict): return '{\n'+''.join('\t'*(level+1)+json.dumps(str(k))+ ' = '+ascii_plist(x,level+1)+';\n' for k,x in v.items())+'\t'*level+'}'
    if isinstance(v,list): return '(\n'+''.join('\t'*(level+1)+ascii_plist(x,level+1)+',\n' for x in v)+'\t'*level+')'
    return str(v) if isinstance(v,int) else json.dumps(v,ensure_ascii=True)
project=root/'OrbitLink.xcodeproj';project.mkdir(exist_ok=True)
(project/'project.pbxproj').write_text('// !$*UTF8*$!\n'+ascii_plist(graph)+'\n',encoding='utf-8')
(project/'project.graph.json').write_text(json.dumps(graph,indent=2),encoding='utf-8')
schemes=project/'xcshareddata/xcschemes';schemes.mkdir(parents=True,exist_ok=True)
(schemes/'OrbitLink.xcscheme').write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
<BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target_app}" BuildableName="OrbitLink.app" BlueprintName="OrbitLink" ReferencedContainer="container:OrbitLink.xcodeproj"/></BuildActionEntry></BuildActionEntries></BuildAction>
<TestAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv="YES"><Testables/></TestAction>
<LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target_app}" BuildableName="OrbitLink.app" BlueprintName="OrbitLink" ReferencedContainer="container:OrbitLink.xcodeproj"/></BuildableProductRunnable></LaunchAction>
<ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"/>
<AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>
''',encoding='utf-8')
print('Xcode project generated:',len(objects),'objects')
