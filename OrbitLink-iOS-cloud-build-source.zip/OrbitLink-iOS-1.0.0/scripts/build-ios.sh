#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
[[ "$(uname -s)" == Darwin ]] || { echo "需要 macOS / Xcode，Windows 无法完成苹果构建。" >&2; exit 1; }
cd "$ROOT"
test -f Frameworks/Libbox.xcframework/Info.plist || { echo "请先运行 bash scripts/build-core.sh" >&2; exit 1; }
swift test
case "${1:-check}" in
  check)
    xcodebuild -project OrbitLink.xcodeproj -scheme OrbitLink -configuration Debug \
      -destination 'generic/platform=iOS' -derivedDataPath .build/DerivedData CODE_SIGNING_ALLOWED=NO build
    ;;
  archive)
    [[ -n "${ORBIT_APPLE_TEAM:-}" ]] || { echo "请在本机提供 ORBIT_APPLE_TEAM（Team ID，不是密码）。" >&2; exit 1; }
    xcodebuild -project OrbitLink.xcodeproj -scheme OrbitLink -configuration Release \
      -destination 'generic/platform=iOS' -archivePath .build/OrbitLink.xcarchive \
      DEVELOPMENT_TEAM="$ORBIT_APPLE_TEAM" archive
    echo "Archive 已创建。请在 Xcode Organizer 选择属于你的分发方式并导出。"
    ;;
  *) echo "用法：bash scripts/build-ios.sh [check|archive]" >&2; exit 1 ;;
esac
