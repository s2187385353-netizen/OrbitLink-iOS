"""Manual macOS build verification. Never signs, exports or labels an IPA as installable."""
from pathlib import Path
import datetime, hashlib, json, os, platform, subprocess, sys

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / 'CloudReports'

def timestamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

def main():
    REPORTS.mkdir(exist_ok=True)
    report = dict(started_at=timestamp(), commit=os.environ.get('GITHUB_SHA'),
                  scope='macOS logic tests, native core build and unsigned iOS device compilation only',
                  steps=[], status='running', installable=False, signed_ipa=False,
                  iphone_connection_test='not_run')
    def save():
        (REPORTS / 'result.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    def run(name, command, env=None):
        step = dict(name=name, status='running', started_at=timestamp())
        report['steps'].append(step); save()
        with (REPORTS / (name + '.log')).open('wb') as log:
            process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            for line in iter(process.stdout.readline, b''):
                log.write(line); log.flush(); sys.stdout.buffer.write(line); sys.stdout.buffer.flush()
            code = process.wait()
        step.update(status='passed' if code == 0 else 'failed', exit_code=code, finished_at=timestamp()); save()
        if code: raise RuntimeError(name + ' failed; inspect ' + name + '.log')
    save()
    try:
        if platform.system() != 'Darwin': raise RuntimeError('A macOS runner with Xcode is required; no compilation was performed.')
        run('xcode-version', ['xcodebuild', '-version'])
        run('swift-version', ['xcrun', 'swift', '--version'])
        run('go-version', ['go', 'version'])
        # Run cheap logic checks first; a test failure must stop the expensive native build.
        run('logic-tests', ['swift', 'test', '--scratch-path', '.build/cloud-logic'])
        environment = os.environ.copy(); environment['ORBIT_CORE_TARGET'] = 'ios/arm64'
        run('native-core', ['bash', 'scripts/build-core.sh'], environment)
        run('unsigned-device-build', ['xcodebuild', '-project', 'OrbitLink.xcodeproj', '-scheme', 'OrbitLink',
            '-configuration', 'Debug', '-destination', 'generic/platform=iOS', '-derivedDataPath', '.build/CloudDevice',
            'CODE_SIGNING_ALLOWED=NO', 'CODE_SIGNING_REQUIRED=NO', 'build'])
        app = ROOT / '.build/CloudDevice/Build/Products/Debug-iphoneos/OrbitLink.app'
        extension = app / 'PlugIns/PacketTunnel.appex'
        if not (app / 'Info.plist').is_file() or not (extension / 'Info.plist').is_file():
            raise RuntimeError('Expected app and embedded PacketTunnel products are missing.')
        report['status'] = 'unsigned_compilation_passed'
        report['note'] = 'Both targets compiled. This is not an installable build and does not prove a working VPN.'
    except Exception as error:
        report['status'] = 'failed'; report['error'] = str(error)
    finally:
        report['finished_at'] = timestamp(); save()
    return 0 if report['status'] == 'unsigned_compilation_passed' else 1

if __name__ == '__main__': raise SystemExit(main())
