#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
[[ "$(uname -s)" == Darwin ]] || { echo "需要 macOS 和 Xcode；此脚本不会在 Windows 上生成假 IPA。" >&2; exit 1; }
xcodebuild -version
command -v go >/dev/null || { echo "请先安装 Go 1.26.8（与固定上游构建环境一致）。" >&2; exit 1; }
[[ "$(go env GOVERSION)" == go1.26.8 ]] || { echo "此构建固定使用 Go 1.26.8，请选择该版本再执行。" >&2; exit 1; }
export GOTOOLCHAIN=local
export GOPATH="$ROOT/.tooling/go"
export GOBIN="$ROOT/.tooling/bin"
export GOMODCACHE="$ROOT/.tooling/modules"
export GOCACHE="$ROOT/.tooling/cache"
export PATH="$GOBIN:$PATH"
mkdir -p "$GOBIN" "$ROOT/.build" "$ROOT/Frameworks"
CORE="$ROOT/.build/sing-box-1.14.3"
if [[ ! -f "$ROOT/Vendor/sing-box-v1.14.3.zip" ]]; then
    mkdir -p "$ROOT/Vendor"
    curl --fail --location --proto '=https' --tlsv1.2 --retry 3 \
      'https://codeload.github.com/SagerNet/sing-box/zip/refs/tags/v1.14.3' \
      --output "$ROOT/Vendor/sing-box-v1.14.3.zip"
fi
echo '5bf11eeb2f5b93377166af1ecdcf24dd2c4be3c92bcb43c09d95edd01eb85949  '"$ROOT/Vendor/sing-box-v1.14.3.zip" | shasum -a 256 -c -
if [[ ! -f "$CORE/go.mod" ]]; then
    /usr/bin/ditto -x -k "$ROOT/Vendor/sing-box-v1.14.3.zip" "$ROOT/.build"
fi
cd "$CORE"
# Install pinned upstream tools after reviewing the corresponding version and license.
go install github.com/sagernet/gomobile/cmd/gomobile@v0.1.13
go install github.com/sagernet/gomobile/cmd/gobind@v0.1.13
# Use only protocols needed by this app; omit unrelated SSH, bridge and desktop features.
gomobile bind -v -target="${ORBIT_CORE_TARGET:-ios,iossimulator}" -iosversion=16.0 -libname=box \
    -tags=with_gvisor,with_quic,with_utls,with_clash_api,with_low_memory,badlinkname,tfogo_checklinkname0,grpcnotrace \
    -trimpath -ldflags='-X github.com/sagernet/sing-box/constant.Version=1.14.3 -s -w -checklinkname=0' \
    -o "$ROOT/Frameworks/Libbox.xcframework" ./experimental/libbox
test -f "$ROOT/Frameworks/Libbox.xcframework/Info.plist"
echo "Libbox 已生成。下一步先运行 swift test，再使用 Xcode 验证两个目标。"
