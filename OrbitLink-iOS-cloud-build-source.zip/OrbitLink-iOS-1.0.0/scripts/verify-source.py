"""Static packaging / Swift grammar checks. This is NOT an Xcode build or XCTest run."""
import argparse, pathlib, re, json, plistlib, struct, hashlib, xml.etree.ElementTree as ET
parser=argparse.ArgumentParser();parser.add_argument('--parser-path');args=parser.parse_args()
root=pathlib.Path(__file__).resolve().parents[1]
if args.parser_path:
    import sys
    sys.path.insert(0,str(pathlib.Path(args.parser_path).resolve()))
checks=[]
def check(name, value):
    checks.append(dict(name=name,passed=bool(value)))
    if not value: raise AssertionError(name)

# Parse actual ASCII plist, including target dependencies and embedded extension.
text=(root/'OrbitLink.xcodeproj/project.pbxproj').read_text(encoding='utf-8')
tokens=re.findall(r'"(?:\\.|[^"\\])*"|[{}()=;,]|[A-Za-z0-9_.$<>/+-]+',re.sub(r'//[^\n]*','',text))
position=0
def value():
    global position
    t=tokens[position];position+=1
    if t=='{':
        out={}
        while tokens[position]!='}':
            key=value();assert tokens[position]=='=';position+=1
            assert key not in out;out[key]=value();assert tokens[position]==';';position+=1
        position+=1;return out
    if t=='(':
        out=[]
        while tokens[position]!=')':
            out.append(value());assert tokens[position]==',';position+=1
        position+=1;return out
    return json.loads(t) if t.startswith('"') or t.isdigit() else t
graph=value();check('PBX ASCII plist parsed',position==len(tokens))
check('PBX graph matches packaged inspection graph',graph==json.loads((root/'OrbitLink.xcodeproj/project.graph.json').read_text()))
objects=graph['objects'];project=objects[graph['rootObject']]
targets={objects[t]['name']:objects[t] for t in project['targets']}
check('App and PacketTunnel targets present',set(targets)=={'OrbitLink','PacketTunnel'})
for name,target in targets.items():
    for phase in target['buildPhases']: check(name+': phase reference resolves',phase in objects)
embed=[objects[p] for p in targets['OrbitLink']['buildPhases'] if objects[p]['isa']=='PBXCopyFilesBuildPhase']
check('PacketTunnel embedded in PlugIns',len(embed)==1 and embed[0]['dstSubfolderSpec']==13 and len(embed[0]['files'])==1)
dependencies=[objects[p] for p in targets['OrbitLink']['dependencies']]
check('App depends on extension',len(dependencies)==1 and objects[dependencies[0]['target']]['name']=='PacketTunnel')
for key,obj in objects.items():
    if obj['isa']=='PBXBuildFile':check('Build file reference resolves: '+key,obj['fileRef'] in objects)
    if obj['isa']=='PBXFileReference' and obj.get('sourceTree')=='SOURCE_ROOT':
        if obj['path']=='Frameworks/Libbox.xcframework':continue
        check('Project file exists: '+obj['path'],(root/obj['path']).exists())
for path in root.rglob('*.plist'): plistlib.loads(path.read_bytes())
app=plistlib.loads((root/'App/App.entitlements').read_bytes());ext=plistlib.loads((root/'PacketTunnel/PacketTunnel.entitlements').read_bytes())
check('App / extension share App Group',app['com.apple.security.application-groups']==ext['com.apple.security.application-groups'])
check('Packet Tunnel entitlement',ext['com.apple.developer.networking.networkextension']==['packet-tunnel-provider'])
info=plistlib.loads((root/'PacketTunnel/Info.plist').read_bytes())
check('Packet Tunnel entry point declared',info['NSExtension']['NSExtensionPointIdentifier']=='com.apple.networkextension.packet-tunnel')
ET.parse(root/'OrbitLink.xcodeproj/xcshareddata/xcschemes/OrbitLink.xcscheme')
icons=root/'App/Assets.xcassets/AppIcon.appiconset'
for icon in json.loads((icons/'Contents.json').read_text())['images']:
    data=(icons/icon['filename']).read_bytes();w,h=struct.unpack('>II',data[16:24]);size=int(float(icon['size'].split('x')[0])*int(icon['scale'][0]))
    check('Icon size/opaque: '+icon['filename'],w==h==size and data[25] in [0,2,3])
for path in root.rglob('*.sh'):check('Shell script LF: '+path.name,b'\r' not in path.read_bytes())
check('Pinned engine source SHA256',hashlib.sha256((root/'Vendor/sing-box-v1.14.3.zip').read_bytes()).hexdigest()=='5bf11eeb2f5b93377166af1ecdcf24dd2c4be3c92bcb43c09d95edd01eb85949')
swift_files=[p for p in root.rglob('*.swift') if 'Vendor' not in p.parts]
syntax=[];syntax_status='not_run'
try:
    import tree_sitter,tree_sitter_swift
    p=tree_sitter.Parser(tree_sitter.Language(tree_sitter_swift.language()))
    for source in swift_files:
        tree=p.parse(source.read_bytes())
        def walk(node):
            if node.type=='ERROR' or node.is_missing:syntax.append(dict(file=str(source.relative_to(root)),line=node.start_point.row+1,type=node.type))
            for child in node.children:walk(child)
        walk(tree.root_node)
    syntax_status='passed' if not syntax else 'failed'
    check('Swift grammar parsing',not syntax)
except ImportError:pass
methods=sum(len(re.findall(r'func test\w+\(',p.read_text(encoding='utf-8'))) for p in (root/'Tests').glob('*.swift'))
report=dict(scope='Static source / packaging and tree-sitter grammar checks only; no Swift type checking, Xcode build, XCTest or iPhone execution',checks=checks,swift_files=len(swift_files),swift_grammar_status=syntax_status,swift_grammar_errors=syntax,xctest_methods_written=methods,xctest_execution='not_run',native_framework='not_built',signed_ipa='not_built',iphone_test='not_run')
(root/'Verification').mkdir(exist_ok=True)
(root/'Verification/source-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(static_checks=len(checks),swift_files=len(swift_files),swift_grammar=syntax_status,xctest_methods_written=methods,xctest_execution='NOT RUN',xcode_build='NOT RUN'),indent=2))
