import Foundation
import NetworkExtension
import Libbox

final class PacketTunnelProvider: NEPacketTunnelProvider {
    var commandServer: LibboxCommandServer?
    private lazy var platform = OrbitPlatform(self)
    private var coordinator: RouteCoordinator?
    private var stopping = false
    private var configContent = ""
    override func startTunnel(options: [String: NSObject]?) async throws {
        stopping = false
        do {
            let catalog = try SharedFiles.load(Catalog.self, "catalog.json", fallback: Catalog())
            let intent = try SharedFiles.load(Intent.self, "intent.json", fallback: Intent())
            guard !catalog.nodes.isEmpty else { throw OrbitError.message("请先导入节点") }
            let root = try SharedFiles.directory()
            let working = root.appendingPathComponent("Core", isDirectory: true)
            let temporary = root.appendingPathComponent("Temp", isDirectory: true)
            for directory in [working, temporary] { try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: [.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication]) }
            let setup = LibboxSetupOptions(); setup.basePath = root.path; setup.workingPath = working.path; setup.tempPath = temporary.path
            setup.logMaxLines = 100; setup.debug = false; setup.oomKillerEnabled = true
            var setupError: NSError?; LibboxSetup(setup, &setupError)
            if let error = setupError { throw error }
            let secret = UUID().uuidString + UUID().uuidString
            let port = Int.random(in: 21000...29000)
            // Validate each outbound independently so one malformed subscription entry
            // cannot prevent all otherwise usable nodes from starting.
            var validNodes: [Node] = []
            for node in catalog.nodes {
                if stopping { throw CancellationError() }
                let config = try Configuration.make(nodes: [node], active: node, secret: secret, port: port)
                var validationError: NSError?; LibboxCheckConfig(config, &validationError)
                if validationError == nil { validNodes.append(node) }
            }
            let requested: [Node]
            if let id = intent.manualID { requested = validNodes.filter { $0.id == id } }
            else if let region = intent.region { requested = validNodes.filter { $0.region == region } }
            else { requested = validNodes }
            guard let active = requested.first else { throw OrbitError.message("所选节点或地区没有通过配置校验的线路，请更换选择") }
            configContent = try Configuration.make(nodes: validNodes, active: active, secret: secret, port: port)
            if stopping { throw CancellationError() }
            var error: NSError?
            commandServer = LibboxNewCommandServer(platform, platform, &error)
            if let error { throw error }
            guard let server = commandServer else { throw OrbitError.message("无法初始化 VPN 核心") }
            try server.start(); try server.startOrReloadService(configContent, options: LibboxOverrideOptions())
            if stopping { throw CancellationError() }
            let routes = RouteCoordinator(control: ClashControl(port: port, secret: secret), nodes: validNodes, active: active, intent: intent)
            coordinator = routes
            platform.onNetworkChanged = { [weak routes] available, signature in Task { await routes?.networkChanged(available: available, signature: signature) } }
            platform.reportCurrentNetwork()
            await routes.start()
            if validNodes.count < catalog.nodes.count { await routes.reportValidationRejections(catalog.nodes.count - validNodes.count) }
        } catch {
            try? commandServer?.closeService(); commandServer?.close(); commandServer = nil; platform.reset()
            var state = Snapshot(); state.phase = stopping ? "disconnected" : "error"
            state.message = stopping ? "已停止连接" : ((error as? OrbitError)?.localizedDescription ?? "VPN 启动失败，请检查节点配置和签名权限")
            state.updatedAt = Date()
            try? SharedFiles.save(state, "snapshot.json")
            throw error
        }
    }
    override func stopTunnel(with reason: NEProviderStopReason) async {
        stopping = true; await coordinator?.stop(); coordinator = nil
        try? commandServer?.closeService(); commandServer?.close(); commandServer = nil
        platform.reset(); configContent = ""
    }
    override func handleAppMessage(_ data: Data) async -> Data? {
        var reply = ProviderReply()
        do {
            guard let coordinator else { throw OrbitError.message("VPN 尚未启动") }
            let request = try JSONDecoder().decode(ProviderRequest.self, from: data)
            // Long-running selection is acknowledged immediately to avoid the provider-message timeout.
            if request.action == "region" || request.action == "manual" {
                Task { do { try await coordinator.command(request) } catch { await coordinator.reportCommandError(error) } }
            } else { try await coordinator.command(request) }
            reply.snapshot = await coordinator.state()
        } catch { reply.error = error.localizedDescription }
        return try? JSONEncoder().encode(reply)
    }
    override func sleep() async { await coordinator?.sleepChanged(true) }
    override func wake() { Task { await coordinator?.sleepChanged(false) } }
    func reloadService() throws { throw OrbitError.message("配置更新后请断开并重新连接") }
    func stopService() { cancelTunnelWithError(nil) }
}
