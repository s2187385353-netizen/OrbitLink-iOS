// Derived in part from SagerNet/sing-box-for-apple, e232aaf22d6d68773196ffc8e6e79684a6be717c.
// Copyright (C) 2022 by nekohasekai. GPL-3.0-or-later. See THIRD_PARTY.md.
import Foundation
import Libbox
import Network
import NetworkExtension
import Darwin

final class OrbitPlatform: NSObject, LibboxPlatformInterfaceProtocol, LibboxCommandServerHandlerProtocol {
    private unowned let tunnel: PacketTunnelProvider
    private var settings: NEPacketTunnelNetworkSettings?
    private var monitor: NWPathMonitor?
    var onNetworkChanged: ((Bool, String) -> Void)?
    init(_ tunnel: PacketTunnelProvider) { self.tunnel = tunnel }

    func openTun(_ options: LibboxTunOptionsProtocol?, ret0_: UnsafeMutablePointer<Int32>?) throws {
        guard let options, let ret0_ else { throw OrbitError.message("缺少虚拟网卡参数") }
        let value = NEPacketTunnelNetworkSettings(tunnelRemoteAddress: "127.0.0.1")
        value.mtu = NSNumber(value: options.getMTU())
        let v4 = options.getInet4Address()!
        var addresses: [String] = []; var masks: [String] = []
        while v4.hasNext() { if let prefix = v4.next() { addresses.append(prefix.address()); masks.append(prefix.mask()) } }
        let ipv4 = NEIPv4Settings(addresses: addresses, subnetMasks: masks)
        ipv4.includedRoutes = [NEIPv4Route.default()]
        var excluded4: [NEIPv4Route] = []
        let ex4 = options.getInet4RouteExcludeAddress()!
        while ex4.hasNext() { if let prefix = ex4.next() { excluded4.append(NEIPv4Route(destinationAddress: prefix.address(), subnetMask: prefix.mask())) } }
        ipv4.excludedRoutes = excluded4; value.ipv4Settings = ipv4
        let v6 = options.getInet6Address()!
        var addresses6: [String] = []; var lengths: [NSNumber] = []
        while v6.hasNext() { if let prefix = v6.next() { addresses6.append(prefix.address()); lengths.append(NSNumber(value: prefix.prefix())) } }
        if !addresses6.isEmpty {
            let ipv6 = NEIPv6Settings(addresses: addresses6, networkPrefixLengths: lengths)
            ipv6.includedRoutes = [NEIPv6Route.default()]
            var excluded6: [NEIPv6Route] = []
            let ex6 = options.getInet6RouteExcludeAddress()!
            while ex6.hasNext() { if let prefix = ex6.next() { excluded6.append(NEIPv6Route(destinationAddress: prefix.address(), networkPrefixLength: NSNumber(value: prefix.prefix()))) } }
            ipv6.excludedRoutes = excluded6; value.ipv6Settings = ipv6
        }
        let dns = try options.getDNSServerAddress()
        var servers: [String] = []
        while dns.hasNext() { servers.append(dns.next()) }
        guard !servers.isEmpty else { throw OrbitError.message("核心未提供 DNS 地址") }
        let dnsSettings = NEDNSSettings(servers: servers); dnsSettings.matchDomains = [""]; dnsSettings.matchDomainsNoSearch = true
        value.dnsSettings = dnsSettings
        try blocking { try await self.tunnel.setTunnelNetworkSettings(value) }
        settings = value
        // Use the core's descriptor discovery rather than private KVC paths on packetFlow.
        let descriptor = LibboxGetTunnelFileDescriptor()
        guard descriptor >= 0 else { throw OrbitError.message("未获得系统虚拟网卡句柄") }
        ret0_.pointee = descriptor
    }
    func usePlatformAutoDetectInterfaceControl() -> Bool { false }
    func autoDetectInterfaceControl(_ fd: Int32) throws {}
    // Compatibility selectors retained by the upstream Apple client.
    func usePlatformAutoDetectControl() -> Bool { false }
    func autoDetectControl(_ fd: Int32) throws {}
    func useProcFS() -> Bool { false }
    func underNetworkExtension() -> Bool { true }
    func includeAllNetworks() -> Bool { false }
    func localDNSTransport() -> (any LibboxLocalDNSTransportProtocol)? { nil }
    func systemCertificates() -> (any LibboxStringIteratorProtocol)? { nil }
    func readWIFIState() -> LibboxWIFIState? { nil }
    func readWIFISSID() -> String? { nil }
    func findConnectionOwner(_ ipProtocol: Int32, sourceAddress: String?, sourcePort: Int32, destinationAddress: String?, destinationPort: Int32) throws -> LibboxConnectionOwner { throw unsupported() }
    func startDefaultInterfaceMonitor(_ listener: LibboxInterfaceUpdateListenerProtocol?) throws {
        guard let listener else { throw OrbitError.message("网络监听器缺失") }
        monitor?.cancel()
        let monitor = NWPathMonitor(); self.monitor = monitor
        let ready = DispatchSemaphore(value: 0)
        monitor.pathUpdateHandler = { [weak self] path in
            guard let self else { return }
            let available = path.status == .satisfied
            let selected = path.availableInterfaces.first(where: { path.usesInterfaceType($0.type) })
            let signature = "\(path.status):\(selected?.name ?? "none"):\(path.isExpensive):\(path.isConstrained)"
            listener.updateNetworkPath(signature)
            listener.updateDefaultInterface(available ? (selected?.name ?? "") : "", interfaceIndex: available ? Int32(selected?.index ?? -1) : -1, isExpensive: path.isExpensive, isConstrained: path.isConstrained)
            self.onNetworkChanged?(available, signature); ready.signal()
        }
        monitor.start(queue: DispatchQueue(label: "com.orbitlink.path"))
        guard ready.wait(timeout: .now() + 8) == .success else { monitor.cancel(); throw OrbitError.message("系统网络状态读取超时") }
    }
    func reportCurrentNetwork() {
        guard let path = monitor?.currentPath else { return }
        let selected = path.availableInterfaces.first(where: { path.usesInterfaceType($0.type) })
        onNetworkChanged?(path.status == .satisfied, "\(path.status):\(selected?.name ?? "none"):\(path.isExpensive):\(path.isConstrained)")
    }
    func closeDefaultInterfaceMonitor(_ listener: LibboxInterfaceUpdateListenerProtocol?) throws { monitor?.cancel(); monitor = nil }
    func getInterfaces() throws -> LibboxNetworkInterfaceIteratorProtocol {
        guard let monitor else { throw OrbitError.message("网络监听尚未启动") }
        let values = monitor.currentPath.availableInterfaces.map { item -> LibboxNetworkInterface in
            let value = LibboxNetworkInterface(); value.name = item.name; value.index = Int32(item.index)
            value.mtu = 1500; value.flags = Int32(IFF_UP | IFF_RUNNING)
            switch item.type { case .wifi: value.type = LibboxInterfaceTypeWIFI; case .cellular: value.type = LibboxInterfaceTypeCellular; case .wiredEthernet: value.type = LibboxInterfaceTypeEthernet; default: value.type = LibboxInterfaceTypeOther }
            return value
        }
        return Interfaces(values)
    }
    private final class Interfaces: NSObject, LibboxNetworkInterfaceIteratorProtocol {
        private var values: [LibboxNetworkInterface]; private var index = 0
        init(_ values: [LibboxNetworkInterface]) { self.values = values }
        func hasNext() -> Bool { index < values.count }
        func next() -> LibboxNetworkInterface? { guard hasNext() else { return nil }; defer { index += 1 }; return values[index] }
    }
    func clearDNSCache() {
        guard let settings else { return }
        // Reapply the settings without briefly removing the default VPN route.
        try? blocking { try await self.tunnel.setTunnelNetworkSettings(settings) }
    }
    func serviceStop() throws { tunnel.stopService() }
    func serviceReload() throws { try tunnel.reloadService() }
    func getSystemProxyStatus() throws -> LibboxSystemProxyStatus { LibboxSystemProxyStatus() }
    func setSystemProxyEnabled(_ enabled: Bool) throws { throw unsupported() }
    func triggerNativeCrash() throws { throw unsupported() }
    func writeDebugMessage(_ message: String?) {}
    func writeLog(_ message: String?) {} // Do not persist server credentials or raw core logs.
    func connectSSHAgent(_ ret0_: UnsafeMutablePointer<Int32>?) throws { throw unsupported() }
    func send(_ notification: LibboxNotification?) throws {}
    func sendNotification(_ notification: LibboxNotification?) throws {}
    func cancelNotification(_ identifier: String?, typeID: Int32) throws {}
    func startNeighborMonitor(_ listener: LibboxNeighborUpdateListenerProtocol?) throws {}
    func closeNeighborMonitor(_ listener: LibboxNeighborUpdateListenerProtocol?) throws {}
    func registerMyInterface(_ name: String?) {}
    func usePlatformShell() -> Bool { false }
    func checkPlatformShell() throws { throw unsupported() }
    func openShellSession(_ user: LibboxPlatformUser?, command: String?, environ: (any LibboxStringIteratorProtocol)?, term: String?, rows: Int32, cols: Int32) throws -> any LibboxShellSessionProtocol { throw unsupported() }
    func lookupUser(_ username: String?) throws -> LibboxPlatformUser { throw unsupported() }
    func lookupSFTPServer(_ error: NSErrorPointer) -> String { error?.pointee = unsupported() as NSError; return "" }
    func readSystemSSHHostKey(_ error: NSErrorPointer) -> String { error?.pointee = unsupported() as NSError; return "" }
    func tailscaleHostname() -> String { "OrbitLink" }
    func usePlatformBridge() -> Bool { false }
    func createBridge(_ options: LibboxBridgeOptions?) throws -> any LibboxBridgeSessionProtocol { throw unsupported() }
    private func unsupported() -> OrbitError { .message("此功能未在 iPhone 版启用") }
    func reset() { monitor?.cancel(); monitor = nil; settings = nil; onNetworkChanged = nil }
}

private final class BlockingResult<T>: @unchecked Sendable { var value: Result<T, Error>? }
private func blocking<T>(_ action: @escaping () async throws -> T) throws -> T {
    let semaphore = DispatchSemaphore(value: 0); let box = BlockingResult<T>()
    Task.detached {
        do { box.value = .success(try await action()) } catch { box.value = .failure(error) }
        semaphore.signal()
    }
    semaphore.wait()
    return try box.value!.get()
}
