import Foundation

/// A single actor owns selection, probes and counters in the VPN extension process.
actor RouteCoordinator {
    private let control: ClashControl
    private let nodes: [Node]
    private var intent: Intent
    private var active: Node
    private var snapshot = Snapshot()
    private var blocked: [String: TimeInterval] = [:]
    private var budget = RecoveryBudget()
    private var revision = UUID()
    private var stopped = false
    private var networkAvailable = true
    private var networkSignature = ""
    private var graceUntil = ProcessInfo.processInfo.systemUptime + 20
    private var selecting = false
    private var sleeping = false
    private var monitorTask: Task<Void, Never>?
    private var lastProbe: TimeInterval = 0
    private var lastTotals: (Double, Double, TimeInterval)?

    init(control: ClashControl, nodes: [Node], active: Node, intent: Intent) {
        self.control = control; self.nodes = nodes; self.active = active; self.intent = intent
        snapshot.activeID = active.id; snapshot.region = intent.region
    }
    func start() {
        snapshot.phase = "checking"; snapshot.message = "正在验证代理链路"; publish()
        monitorTask = Task { [weak self] in
            while !Task.isCancelled {
                await self?.tick()
                do { try await Task.sleep(nanoseconds: 3_000_000_000) } catch { break }
            }
        }
        if let region = intent.region { Task { await self.choose(region: region) } }
    }
    func stop() {
        stopped = true; revision = UUID(); monitorTask?.cancel(); monitorTask = nil
        snapshot.phase = "disconnected"; snapshot.message = "已断开"; snapshot.upload = 0; snapshot.download = 0; publish()
    }
    func sleepChanged(_ value: Bool) { sleeping = value; if !value { graceUntil = now + 20; lastTotals = nil } }
    private var now: TimeInterval { ProcessInfo.processInfo.systemUptime }
    func networkChanged(available: Bool, signature: String) {
        networkAvailable = available
        if signature != networkSignature {
            networkSignature = signature; graceUntil = now + 20; budget.healthy(); lastTotals = nil
            if !available { snapshot.phase = "offline"; snapshot.message = "等待 Wi-Fi 或移动网络"; snapshot.upload = 0; snapshot.download = 0 }
            else { snapshot.phase = "checking"; snapshot.message = "网络已变化，正在恢复连接" }
            publish()
        }
    }
    func state() -> Snapshot { snapshot }
    func command(_ request: ProviderRequest) async throws {
        switch request.action {
        case "region":
            guard let region = request.region, Regions.all.contains(region), region != "未识别" else { throw OrbitError.message("请选择已识别地区") }
            await choose(region: region)
        case "manual":
            guard let node = nodes.first(where: { $0.id == request.nodeID }) else { throw OrbitError.message("节点不存在，请重新连接以载入新节点") }
            let token = UUID(); revision = token; selecting = true
            defer { if revision == token { selecting = false } }
            try await control.select(node)
            guard !stopped, token == revision else { return }
            active = node; intent.region = nil; intent.manualID = node.id; try SharedFiles.save(intent, "intent.json")
            budget.healthy(); snapshot.region = nil; snapshot.activeID = node.id; snapshot.phase = "checking"
            snapshot.message = "手动选择，正在验证连接"; graceUntil = now + 10; lastProbe = 0; event("已手动选择节点，退出地区自动优选"); publish()
        case "snapshot": break
        default: throw OrbitError.message("未知操作")
        }
    }
    func reportCommandError(_ error: Error) { snapshot.message = error.localizedDescription; publish() }
    func reportValidationRejections(_ count: Int) { event("已跳过 \(count) 个核心配置校验失败的节点"); publish() }
    func choose(region: String) async {
        let token = UUID(); revision = token; selecting = true
        defer { if revision == token { selecting = false } }
        intent.region = region; intent.manualID = nil; snapshot.region = region
        do { try SharedFiles.save(intent, "intent.json") } catch { snapshot.message = "无法保存地区偏好"; publish(); return }
        let candidates = nodes.filter { $0.region == region && (blocked[$0.id] ?? 0) <= now }
        guard !candidates.isEmpty else { snapshot.phase = "degraded"; snapshot.message = "该地区暂无可用候选节点，稍后重试"; graceUntil = now + 60; publish(); return }
        snapshot.phase = "testing"; snapshot.message = "正在检测\(region)节点，完成后自动连接最优线路"; publish()
        await measure(candidates, token: token)
        guard token == revision, !stopped, networkAvailable else { return }
        let ranked = RoutePolicy.rank(nodes, region: region, quality: snapshot.qualities, blocked: blocked, now: now)
        let previous = active
        for node in ranked {
            do {
                try await control.select(node)
                guard token == revision, !stopped else { return }
                active = node; snapshot.activeID = node.id
                // A stale warm test does not establish current connection health.
                let delay = await health(node)
                guard token == revision, !stopped else { return }
                if delay < 0 { blocked[node.id] = now + 600; continue }
                healthy(delay); graceUntil = now + 20; event("\(region)优选已连接：\(node.name)"); publish(); return
            } catch { if token != revision || stopped { return } }
        }
        if active.id != previous.id, token == revision, !stopped, networkAvailable {
            do { try await control.select(previous); if token == revision, !stopped { active = previous; snapshot.activeID = previous.id } }
            catch { /* Keep the actual last selected node visible if restoring also fails. */ }
        }
        snapshot.phase = "degraded"; snapshot.message = "该地区检测未通过，保留当前线路并继续恢复"; graceUntil = now + 60; publish()
    }
    private func measure(_ candidates: [Node], token: UUID) async {
        // Bound parallelism to three to limit memory use in the iOS VPN extension.
        for offset in stride(from: 0, to: candidates.count, by: 3) {
            guard token == revision, !stopped, networkAvailable else { return }
            let batch = Array(candidates[offset..<min(offset + 3, candidates.count)])
            let control = self.control
            let values = await withTaskGroup(of: (String, Quality).self, returning: [(String, Quality)].self) { group in
                for node in batch {
                    group.addTask {
                        var samples: [Int] = []
                        for _ in 0..<3 { samples.append(await control.delay(node)) }
                        return (node.id, Quality(samples: samples, testedAt: ProcessInfo.processInfo.systemUptime))
                    }
                }
                var values: [(String, Quality)] = []
                for await value in group { values.append(value) }
                return values
            }
            guard token == revision, !stopped, networkAvailable else { return }
            for (id, quality) in values { snapshot.qualities[id] = quality }
            publish()
        }
    }
    private func health(_ node: Node) async -> Int {
        let first = await control.delay(node)
        if first >= 0 { return first }
        return await control.delay(node, endpoint: "https://www.google.com/generate_204")
    }
    private func healthy(_ delay: Int) {
        budget.healthy(); snapshot.failures = 0; snapshot.latency = delay
        snapshot.phase = "connected"; snapshot.message = "代理链路已验证"
    }
    private func tick() async {
        guard !stopped else { return }
        let token = revision
        if !sleeping, networkAvailable {
            do {
                let totals = try await control.totals()
                guard token == revision, !stopped else { return }
                let t = now
                if let last = lastTotals, t > last.2 {
                    snapshot.upload = max(0, totals.0 - last.0) / (t - last.2)
                    snapshot.download = max(0, totals.1 - last.1) / (t - last.2)
                }
                snapshot.totalUpload = totals.0; snapshot.totalDownload = totals.1
                lastTotals = (totals.0, totals.1, t)
            } catch { snapshot.upload = 0; snapshot.download = 0 }
        }
        guard !stopped, token == revision else { return }
        publish()
        guard networkAvailable, !selecting, now >= graceUntil, now - lastProbe >= (sleeping ? 60 : 15) else { return }
        lastProbe = now
        if let region = intent.region, active.region != region { await choose(region: region); return }
        let node = active
        let delay = await health(node)
        guard token == revision, !stopped, networkAvailable, now >= graceUntil else { return }
        if delay >= 0 { healthy(delay); publish(); return }
        budget.failed(); snapshot.failures = budget.failures; snapshot.latency = nil
        snapshot.phase = "degraded"; snapshot.message = "链路检测失败 \(budget.failures) 次"; publish()
        guard intent.automaticRecovery, budget.canSwitch(now: now) else { return }
        guard let region = intent.region else { snapshot.message = "手动节点异常，请选择地区以启用备用线路"; publish(); return }
        selecting = true
        defer { if revision == token { selecting = false } }
        let backups = nodes.filter { $0.region == region && $0.id != active.id && (blocked[$0.id] ?? 0) <= now }
        await measure(backups, token: token)
        guard token == revision, !stopped, networkAvailable else { return }
        let ranked = RoutePolicy.rank(nodes, region: region, quality: snapshot.qualities, blocked: blocked, now: now, excluding: active.id)
        for next in ranked {
            do {
                try await control.select(next)
                guard token == revision, !stopped else { return }
                active = next; snapshot.activeID = next.id; snapshot.latency = nil
                let checked = await health(next)
                guard token == revision, !stopped else { return }
                guard checked >= 0 else { blocked[next.id] = now + 600; continue }
                blocked[node.id] = now + 600; active = next; snapshot.activeID = next.id
                budget.switched(now: now); healthy(checked); graceUntil = now + 20
                event("连续失败 3 次，已切换\(region)备用线路：\(next.name)"); publish(); return
            } catch { if token != revision || stopped { return } }
        }
        // Restore actual selector to the displayed node if all replacement attempts failed.
        do { try await control.select(node); if token == revision, !stopped { active = node; snapshot.activeID = node.id } }
        catch { /* The last successfully selected node remains the actual active node. */ }
        guard token == revision, !stopped else { return }
        budget.switched(now: now); snapshot.phase = "degraded"; snapshot.message = "同地区没有检测通过的备用线路，稍后重试"; publish()
    }
    private func event(_ text: String) { snapshot.events.insert(RouteEvent(text: text), at: 0); snapshot.events = Array(snapshot.events.prefix(20)) }
    private func publish() {
        snapshot.blockedUntil = blocked
        snapshot.updatedAt = Date()
        do { try SharedFiles.save(snapshot, "snapshot.json") } catch { /* UI can still request the in-memory snapshot. */ }
    }
}
