import Foundation

/// The controller binds only to loopback and requires a fresh per-session bearer token.
actor ClashControl {
    let port: Int; let secret: String
    private let session: URLSession
    private var selectionTask: Task<Void, Error>?
    init(port: Int, secret: String) {
        self.port = port; self.secret = secret
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 8; config.timeoutIntervalForResource = 10
        config.urlCache = nil; config.httpCookieStorage = nil
        config.connectionProxyDictionary = [:]
        session = URLSession(configuration: config)
    }
    private func request(_ path: [String], query: [URLQueryItem] = [], method: String = "GET", body: Data? = nil) async throws -> Data {
        var url = URL(string: "http://127.0.0.1:\(port)")!
        for component in path { url.appendPathComponent(component) }
        var c = URLComponents(url: url, resolvingAgainstBaseURL: false)!; c.queryItems = query.isEmpty ? nil : query
        var r = URLRequest(url: c.url!); r.httpMethod = method; r.httpBody = body
        r.setValue("Bearer " + secret, forHTTPHeaderField: "Authorization")
        if body != nil { r.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        let (data, response) = try await session.data(for: r)
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else { throw OrbitError.message("核心控制请求失败") }
        return data
    }
    func delay(_ node: Node, endpoint: String = "https://www.gstatic.com/generate_204") async -> Int {
        do {
            let data = try await request(["proxies", node.tag, "delay"], query: [.init(name: "url", value: endpoint), .init(name: "timeout", value: "5000")])
            let json = try JSONDecoder().decode([String: Int].self, from: data)
            return (json["delay"] ?? 0) > 0 ? json["delay"]! : -1
        } catch { return -1 }
    }
    func select(_ node: Node) async throws {
        let previous = selectionTask
        let task = Task { [self] in
            _ = try? await previous?.value
            _ = try await request(["proxies", "orbit"], method: "PUT", body: JSONEncoder().encode(["name": node.tag]))
        }
        selectionTask = task
        try await task.value
    }
    func totals() async throws -> (Double, Double) {
        struct Totals: Decodable { let uploadTotal: Double; let downloadTotal: Double }
        let value = try JSONDecoder().decode(Totals.self, from: await request(["connections"]))
        return (value.uploadTotal, value.downloadTotal)
    }
}
