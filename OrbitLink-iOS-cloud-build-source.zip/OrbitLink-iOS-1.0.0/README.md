# 星枢 · OrbitLink iOS 1.0 开发工程

适配目标：iPhone 13，iOS 16 或更高版本。**这是开发源码，不是能直接安装的 IPA。当前 Windows 环境没有完成 Xcode 编译、苹果签名或 iPhone 真机连接验证。**

## 本次实际交付

- 原生 SwiftUI 首页、地区页、设置页，沿用星枢图标与青紫动态轨道；系统开启“减弱动态效果”时自动停止动画。
- 日本、美国、新加坡、台湾为主要分组，香港和未识别单独展示。点击地区请求后台三轮检测并自动选择，列表显示真实检测结果，不需要右键设为活动服务器。
- 成功率、延迟与波动综合排序；连续 3 次代理健康检查失败后，重新验证并切换同地区备用节点；故障节点暂时隔离 10 分钟，切换冷却 90 秒，每 10 分钟最多 3 次。
- Wi-Fi / 蜂窝切网后等待 20 秒，物理网络断开时暂停故障计数。监测放在 VPN 扩展进程内，应用进入后台后不依赖前台界面计时器。实际锁屏持续运行与耗电尚待真机测试。
- 上下行速度和累计流量来自核心计数器；灰色未连接、黄色检测/异常、绿色链路已验证；VPN 系统状态也会参与判断。
- 分享链接、二维码、HTTPS 订阅、Base64 订阅、sing-box JSON 导入；支持常见 VLESS（TLS/Reality、WS/gRPC）、VMess、Trojan、SS、HY2。TUIC 目前通过 sing-box JSON 导入。暂不支持 Clash YAML、SS 插件及所有协议扩展参数，无法识别的条目会被报告并跳过。
- 用户主动断开时先取消系统按需启动。手动选点退出地区优选；恢复记录只保存节点别名和时间，不保存订阅地址、密码或原始核心日志。

尚无真实连接测量数据，因此不能保证后台不断线、切换速度或与全部机场订阅兼容。已有桌面和安卓版本不会被本工程修改。

## 当前缺少的构建条件

1. 可运行 Xcode 的 Mac；项目使用苹果 iOS SDK，Windows 不能执行此编译。
2. 可以为 App 和 Packet Tunnel 扩展签名、启用 Network Extensions / App Groups 的 Apple Developer 团队与配置。普通 Apple ID 不应被当作已经具备这些权限。
3. iPhone 13 真机，确认其 iOS 版本不低于 16。账号密码、私钥和证书均在自己的 Mac 上配置，勿发到聊天中。

当前没有 Mac 和开发者账号时，先保留此源码包；准备构建条件后可继续完成编译、签名和实机验证。此交付不要求越狱，不包含签名绕过方案，也没有替你注册付费服务或上传代码到外部仓库。

## 在 Mac 上继续构建

1. 安装 Xcode 和 Go **1.26.8**；在 Xcode 选择实际可用的开发团队。在 `Configuration/Project.xcconfig` 修改 `APP_IDENTIFIER`、`APP_GROUP_IDENTIFIER` 为该团队拥有的唯一标识。
2. 在 App 与 PacketTunnel 两个目标上启用相同 App Groups，并启用 Network Extensions / Packet Tunnel。两套签名配置必须同时有效。
3. 运行 `bash scripts/build-core.sh`。它校验随包核心源码哈希，使用固定 gomobile v0.1.13 在本地生成 `Frameworks/Libbox.xcframework`，不上传代码。首次需要联网下载 Go 依赖。
4. 运行 `swift test`。15 个 XCTest 测试方法覆盖地区识别、过期结果、推荐排序、故障阈值、切换预算、导入格式和配置结构。**本次未执行这些 Swift 单元测试。**
5. 运行 `bash scripts/build-ios.sh check`，执行实际 Xcode 编译检查。需修复苹果 SDK / 生成绑定报告的实际问题；语法解析通过不代表所有 Swift 类型、协议签名和链接已通过。
6. 打开 `OrbitLink.xcodeproj`，选择 iPhone 13，进行首次运行并同意系统添加 VPN 配置。VPN 扩展必须在真机验收，模拟器仅用于页面检查。
7. 签名条件齐备后，可在本机提供 Team ID 并运行 `ORBIT_APPLE_TEAM=你的TeamID bash scripts/build-ios.sh archive`。随后在 Xcode Organizer 选择自己具备权限的分发方式。没有导出通用、免签且任意 iPhone 都能安装的包。

## 必须完成的真实验收

详见 `ACCEPTANCE.md`。最低要求为：常见节点逐协议连接；点地区后无需手选；真实上传/下载；连续故障触发同地区切换；没有可用备份时明确提示；快速连点最终选择正确；主动停止后不会自动启动；锁屏与 Wi-Fi/蜂窝切换；首次授权拒绝、无网、错误订阅及异常证书处理。

## 工程结构

- `App/`：原生页面、扫码和 VPN 管理。
- `Shared/`：纯逻辑、分享解析、配置生成、受系统文件保护的本机共享文件。
- `PacketTunnel/`：NetworkExtension、Libbox 平台适配和后台选优/恢复。
- `Tests/`：可在 Mac 运行的 Swift 单元测试。
- `Vendor/`：固定核心源码和上游参考文件、许可证；未夹带用户节点或证书。
- `Verification/`：本次实际执行的检查报告。没有 Xcode 成功日志时，不能把本工程描述为已构建可安装版本。

许可和依赖见 `THIRD_PARTY.md` 与 `LICENSE`。设计预览是示意稿，使用示例状态，不是真机截图或真实速度数据。
