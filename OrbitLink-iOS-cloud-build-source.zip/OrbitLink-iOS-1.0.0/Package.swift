// swift-tools-version: 5.9
import PackageDescription
let package = Package(
    name: "OrbitLogic",
    platforms: [.macOS(.v13), .iOS(.v16)],
    products: [.library(name: "OrbitLogic", targets: ["OrbitLogic"])],
    targets: [.target(name: "OrbitLogic", path: "Shared", exclude: ["SharedFiles.swift"]), .testTarget(name: "OrbitLogicTests", dependencies: ["OrbitLogic"], path: "Tests")]
)
